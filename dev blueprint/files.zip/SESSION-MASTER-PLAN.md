# Implementation Session Master Plan

> **PURPOSE:** Defines the exact order and scope of every Claude Code session.
> Each session has its own blueprint file: `SESSION-XX-title.md`
> Sessions are ordered by dependency — each builds only on what previous sessions delivered.

---

## WHAT'S ALREADY BUILT (Skip List)

These features are implemented and working. Sessions must not rewrite them — only integrate with them.

| Feature | Module(s) | Key Files |
|---------|-----------|-----------|
| Photo picker (albums, multi-select, preview, strip) | `:feature:picker` | PhotoPickerScreen, PhotoPickerViewModel, MediaRepositoryImpl |
| Collage canvas (20+ layouts, drag-to-reorder, per-photo crop/rotate/flip) | `:feature:canvas` | CanvasScreen, CanvasViewModel, EditableTouchImageView |
| Whole-image editor (crop 8-handle, rotate, flip, 8 adjustments) | `:feature:editor` | WholeImageEditScreen, WholeImageEditView, AdjustmentPanel |
| Image processing (decode, crop, stitch, guided filter, AGSL, GPUImage) | `:core:image` | BitmapService, GuidedFilter, ColorSpace |
| Layout engine (normalized cells, dynamic grid 7+) | `:core:model` | CollageLayout.kt |
| All annotation data models (13 types) | `:core:model` | Annotation.kt, AnnotationStyle.kt |
| Project data model (layers, calibration, transforms) | `:core:model` | Project.kt, Layer.kt, Geometry.kt |
| Monochrome design system (theme, 6 components) | `:core:ui` | TechNotesTheme, components |
| Navigation (manual routing Canvas→Picker→Editor) | `:app` | AppNavigation.kt |
| Hilt DI | `:app` | AppModule.kt, TechNotesApplication.kt |

**Current architecture:** minSdk 29, targetSdk 36, JVM 21, Compose BOM, MVVM + Repository + Hilt. Native View zoom (not Compose gestures). AndroidView interop for drawing surfaces.

---

## SESSION DEPENDENCY GRAPH

```
PHASE A — CORE INFRASTRUCTURE
  S01: Mode System ──────────────────────────────┐
  S02: Undo/Redo Engine (depends: S01) ──────────┤
  S03: Drawing Surface + Coordinate Layer (S01) ──┤
                                                  │
PHASE B — UI CHROME                               │
  S04: Browse Mode Chrome (S01) ──────────────────┤
  S05: Annotate Mode Chrome + Auto-Hide (S01) ────┤
  S06: Edit Mode Chrome (S01) ────────────────────┤
                                                  │
PHASE C — TOOL SYSTEM                             │
  S07: Tool Palette Architecture (S05) ────────── │
  S08: Snap Engine (S03) ─────────────────────────┤
                                                  │
PHASE D — DRAWING PRIMITIVES                      │
  S09: Two-Point Lines + Selection (S07, S08) ────┤
  S10: Arrowhead Renderer — 20 styles (S09) ──────┤
  S11: Tap-to-Place Shapes (S07) ─────────────────┤
  S12: Text Tool (S07) ───────────────────────────┤
  S13: Freehand Drawing + Smooth Curves (S07,S08) ┤
  S14: Drag-Area Shapes — hatching, cloud (S13) ──┤
  S15: Leader + Text (S09, S12) ──────────────────┤
  S16: Tap-on-Line Marks (S09) ───────────────────┤
  S17: Measurement Tools — dimensions (S09, S10) ──┤
                                                  │
PHASE E — PROPERTIES & LAYERS                     │
  S18: Properties Sheet System (S07) ─────────────┤
  S19: Layer Panel (S05) ─────────────────────────┤
                                                  │
PHASE F — OVERLAYS                                │
  S20: Overlay Core (S06) ────────────────────────┤
  S21: Overlay Masks & Blend Modes (S20) ─────────┤
  S22: Overlay Chroma Key + Feathering (S21) ──── │
                                                  │
PHASE G — PERSISTENCE & EXPORT                    │
  S23: Project Save / Load (S04) ─────────────────┤
  S24: Auto-Save (S23) ──────────────────────────┤
  S25: Export — PDF + JPG (S04) ──────────────────┤
                                                  │
PHASE H — ADVANCED FEATURES                       │
  S26: Engineering Keyboard + Symbols (S12) ──────┤
  S27: More Catalog + Search (S07) ───────────────┤
  S28: Wizard Builders (S18) ─────────────────────┤
  S29: Advanced Tools #46-#50 (S13, S11) ─────────┤
  S30: Video-to-GIF [deferred] ───────────────────┤
                                                  │
PHASE I — POLISH                                  │
  S31: Accessibility, Tooltips, Performance (ALL) ┘
```

---

## SESSION OVERVIEW TABLE

| # | Title | Phase | Complexity | Est. Effort | Depends On | Blueprint File |
|---|-------|-------|------------|-------------|------------|----------------|
| 01 | Mode System + Transitions | A | MEDIUM | 1 session | — | `SESSION-01-mode-system.md` |
| 02 | Undo/Redo Engine | A | MEDIUM | 1 session | S01 | `SESSION-02-undo-redo.md` |
| 03 | Drawing Surface + Coordinate Layer | A | HIGH | 1-2 sessions | S01 | `SESSION-03-drawing-surface.md` |
| 04 | Browse Mode Chrome | B | MEDIUM | 1 session | S01 | `SESSION-04-browse-chrome.md` |
| 05 | Annotate Mode Chrome + Auto-Hide | B | MEDIUM | 1 session | S01 | `SESSION-05-annotate-chrome.md` |
| 06 | Edit Mode Chrome | B | MEDIUM | 1 session | S01 | `SESSION-06-edit-chrome.md` |
| 07 | Tool Palette Architecture | C | HIGH | 1-2 sessions | S05 | `SESSION-07-tool-palette.md` |
| 08 | Snap Engine | C | HIGH | 1-2 sessions | S03 | `SESSION-08-snap-engine.md` |
| 09 | Two-Point Lines + Selection | D | HIGH | 2 sessions | S07, S08 | `SESSION-09-lines.md` |
| 10 | Arrowhead Renderer | D | MEDIUM | 1 session | S09 | `SESSION-10-arrowheads.md` |
| 11 | Tap-to-Place Shapes | D | HIGH | 1-2 sessions | S07 | `SESSION-11-shapes.md` |
| 12 | Text Tool | D | MEDIUM | 1 session | S07 | `SESSION-12-text-tool.md` |
| 13 | Freehand Drawing + Smooth Curves | D | HIGH | 1-2 sessions | S07, S08 | `SESSION-13-freehand.md` |
| 14 | Drag-Area Shapes | D | MEDIUM | 1 session | S13 | `SESSION-14-drag-area-shapes.md` |
| 15 | Leader + Text | D | LOW | 1 session | S09, S12 | `SESSION-15-leader-text.md` |
| 16 | Tap-on-Line Marks | D | MEDIUM | 1 session | S09 | `SESSION-16-marks.md` |
| 17 | Measurement Tools | D | HIGH | 1-2 sessions | S09, S10 | `SESSION-17-measurements.md` |
| 18 | Properties Sheet System | E | HIGH | 2 sessions | S07 | `SESSION-18-properties.md` |
| 19 | Layer Panel | E | MEDIUM | 1 session | S05 | `SESSION-19-layers.md` |
| 20 | Overlay Core | F | HIGH | 1-2 sessions | S06 | `SESSION-20-overlay-core.md` |
| 21 | Overlay Masks & Blend Modes | F | HIGH | 1-2 sessions | S20 | `SESSION-21-overlay-masks.md` |
| 22 | Overlay Chroma Key + Feathering | F | MEDIUM | 1 session | S21 | `SESSION-22-overlay-chroma.md` |
| 23 | Project Save / Load | G | MEDIUM | 1 session | S04 | `SESSION-23-project-save.md` |
| 24 | Auto-Save | G | LOW | 1 session | S23 | `SESSION-24-auto-save.md` |
| 25 | Export — PDF + JPG | G | MEDIUM | 1 session | S04 | `SESSION-25-export.md` |
| 26 | Engineering Keyboard + Symbols | H | MEDIUM | 1 session | S12 | `SESSION-26-eng-keyboard.md` |
| 27 | More Catalog + Search | H | MEDIUM | 1 session | S07 | `SESSION-27-catalog.md` |
| 28 | Wizard Builders | H | HIGH | 2 sessions | S18 | `SESSION-28-wizards.md` |
| 29 | Advanced Tools #46-#50 | H | HIGH | 2 sessions | S13, S11 | `SESSION-29-advanced-tools.md` |
| 30 | Video-to-GIF | H | MEDIUM | 1 session | — | `SESSION-30-video-gif.md` |
| 31 | Accessibility, Tooltips, Polish | I | MEDIUM | 1-2 sessions | ALL | `SESSION-31-polish.md` |

**Total: 31 sessions, ~38-46 working sessions accounting for complexity splits**

---

## RECOMMENDED EXECUTION ORDER

Sessions can run in parallel within a phase, but the phases are strictly sequential. Within Phase D, the recommended linear order is: S09 → S10 → S11 → S12 → S13 → S14 → S15 → S16 → S17.

**Critical path (longest dependency chain):**
S01 → S05 → S07 → S09 → S10 → S17 (measurement tools with arrowheads on dimension lines)

**Early wins (high value, lower complexity):**
S01 → S04 → S23 (mode system → browse chrome → save/load gives a working project shell fast)

---

## SESSION BLUEPRINT FILE FORMAT

Every `SESSION-XX-title.md` follows this exact structure so Claude Code can parse it predictably:

```markdown
# Session XX — Title

## GOAL
{One sentence: what this session delivers}

## DEPENDS ON
{List of prerequisite sessions that must be complete}

## SPEC REFERENCES
{Exact file names and section numbers to read before coding}

## EXISTING CODE TO INTEGRATE WITH
{Files and modules that already exist and must not be rewritten}

## DELIVERABLES
{Numbered list of concrete outputs — classes, files, behaviors}

## DATA MODELS
{Exact Kotlin data classes and enums this session creates or modifies}

## KEY IMPLEMENTATION DETAILS
{Spec excerpts, algorithms, code patterns — everything Claude Code needs
 without opening other files}

## RESOLVED CONFLICTS
{Any R-XX resolutions from IMPLEMENTATION-BLUEPRINT that apply}

## STUB REQUIREMENTS
{Features mentioned but deferred — what stub to create}

## TEST CRITERIA
{Numbered checklist of manual test steps}

## FILES TO CREATE / MODIFY
{Explicit list: module, package, filename, purpose}
```

---

## RULES FOR EACH SESSION

1. **Read STATUS.md first** — confirm prerequisites are met
2. **Read the session blueprint file** — it contains all needed spec excerpts
3. **Do NOT open other spec files** unless the blueprint says to
4. **Create ITERATION-LOG-XX.md** at session start
5. **Implement in :core first, then :sandbox**
6. **Build and deploy after every change**
7. **Consolidate before writing SANDBOX-REPORT**
8. **Update STATUS.md** after session completion

---

*Master Plan v1.0 — April 2026*
