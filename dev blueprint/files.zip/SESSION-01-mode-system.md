# Session 01 — Mode System + Transitions

## GOAL

Implement the three-mode state machine (BROWSE / ANNOTATE / EDIT) with visual indicators, transition logic, and top bar reconfiguration that drives all future UI state.

## DEPENDS ON

Nothing — this is the first session. However, the following existing code must be understood and integrated with:

## SPEC REFERENCES

Read before coding:
- `INTERACTION-SPEC.md` §2 (Mode System), §15 (Mode Transitions)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-02 (Three Modes)
- Resolution R-08 (Edit Mode Cancel + Undo Stack)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `CanvasScreen.kt` | `:feature:canvas` | ~388 lines, main composable with toolbar and permissions | Mode state will drive what this screen shows |
| `CanvasViewModel.kt` | `:feature:canvas` | ~254 lines, canvas state management | Add `AppMode` StateFlow here |
| `EditableTouchImageView.kt` | `:feature:canvas` | ~969 lines, multi-photo touch interaction | Touch behavior changes per mode |
| `AppNavigation.kt` | `:app` | Manual routing between screens | Mode transitions don't navigate — they reconfigure CanvasScreen |
| `WholeImageEditScreen.kt` | `:feature:editor` | ~255 lines, full-screen crop/rotate editor | This is a NAVIGATION target, not a mode. Accessed via "More → Edit Whole Image" in Edit Mode. |

**Critical understanding:** Mode transitions happen WITHIN CanvasScreen. They do not navigate to different screens. The top bar, bottom bar, and touch behavior reconfigure based on the current mode.

## DELIVERABLES

1. **`AppMode` enum** in `:core:model` — `BROWSE`, `ANNOTATE`, `EDIT`
2. **`CanvasViewModel.currentMode: StateFlow<AppMode>`** — drives all UI state
3. **Mode transition functions** in CanvasViewModel:
   - `enterAnnotateMode()` — from BROWSE only
   - `exitAnnotateMode()` — returns to BROWSE
   - `enterEditMode(photoIndex: Int)` — from BROWSE only, specifies which photo
   - `exitEditMode(apply: Boolean)` — `true` = Done (apply changes), `false` = Cancel (revert)
   - No direct ANNOTATE ↔ EDIT transition (always through BROWSE)
4. **Visual mode indicators** — Compose:
   - ANNOTATE: 2dp blue accent bar at top edge (below status bar)
   - EDIT: 2dp cyan accent bar at top edge
   - BROWSE: no accent bar
5. **Top bar reconfiguration** per mode — shell layout only, buttons are placeholder:
   - BROWSE: `☰ Menu | Project Name ● | ↩ ↪ | ⬆ | ⋮`
   - ANNOTATE: `✕ Done | Tool Name + Snap Info | 🔲 ⚙`
   - EDIT: `✕ Cancel | "Edit: Photo N" | ✓ Done`
   - (Buttons are visible but non-functional except the mode transition ones)
6. **Bottom area reconfiguration** per mode — empty placeholder containers:
   - BROWSE: space for FABs and thumbnail bar (actual content in S04)
   - ANNOTATE: empty 56dp toolbar placeholder (actual tools in S07)
   - EDIT: empty 56dp toolbar placeholder (actual tools in S06)
7. **Mode entry gestures/buttons:**
   - ✏ FAB tap → `enterAnnotateMode()` (FAB is placeholder, wired in S04)
   - Long-press photo → `enterEditMode(photoIndex)` (wire into EditableTouchImageView)
   - ✎ icon tap → `enterEditMode(0)` (single photo only, icon added in S04)
8. **Mode exit:**
   - Back gesture / ✕ → returns to BROWSE from any mode
   - ANNOTATE ✕ Done → `exitAnnotateMode()`
   - EDIT ✕ Cancel → show confirmation dialog → `exitEditMode(false)`
   - EDIT ✓ Done → `exitEditMode(true)`
9. **Cancel confirmation dialog** (per R-08):
   - "Discard all changes?" with [Discard] and [Keep Editing] buttons
   - Shown only when `exitEditMode(false)` is called
10. **Cross-fade animation** (200ms) for chrome elements on mode transition

## DATA MODELS

```kotlin
// In :core:model — new file AppMode.kt
enum class AppMode {
    BROWSE,    // Default. View photos, manage project, access FABs
    ANNOTATE,  // Draw annotations on canvas. Chrome auto-hides during drawing.
    EDIT       // Edit individual photo: flip, rotate, crop, adjust, overlay
}
```

```kotlin
// In CanvasViewModel — new state fields
data class CanvasUiState(
    val mode: AppMode = AppMode.BROWSE,
    val editingPhotoIndex: Int = -1,       // Which photo is being edited (-1 = none)
    val showCancelDialog: Boolean = false,  // Edit mode cancel confirmation
    val topBarTitle: String = "",           // Dynamic: project name / tool name / "Edit: Photo N"
)
```

## KEY IMPLEMENTATION DETAILS

### Mode Transition Rules (from INTERACTION-SPEC §2)

```
BROWSE is the home state. User views their work, manages project.
ANNOTATE is entered via ✏ FAB. User draws annotations on the photo.
EDIT is entered via long-press photo or ✎ icon. User edits one photo's properties.

Transitions:
  BROWSE → ANNOTATE:  ✏ FAB tap
  ANNOTATE → BROWSE:  ✕ Done button, Back gesture
  BROWSE → EDIT:      Long-press photo, ✎ icon (single photo)
  EDIT → BROWSE:      ✓ Done button, ✕ Cancel (with confirmation)
  ANNOTATE ↔ EDIT:    NOT ALLOWED. Must go through BROWSE.
```

### Visual Indicators (from INTERACTION-SPEC §2)

```
BROWSE:   No accent bar. Clean viewing.
ANNOTATE: 2dp bar, blue (#2196F3). Sits below status bar, above content.
EDIT:     2dp bar, cyan (#00BCD4). Same position.
```

The accent bar is a simple `Box(Modifier.fillMaxWidth().height(2.dp).background(color))` at the top of the content area, animated with `AnimatedVisibility` or `animateColorAsState`.

### Top Bar Layout Pattern

```
┌─────────────────────────────────────────────────────────────┐
│  [Left Action]    [Center Title]              [Right Actions] │
└─────────────────────────────────────────────────────────────┘

BROWSE:    ☰              "My Project ●"         ↩  ↪  ⬆  ⋮
ANNOTATE:  ✕ Done         "Straight Line • Snap 45°"   🔲  ⚙
EDIT:      ✕ Cancel       "Edit: Photo 2"               ✓ Done
```

All three layouts use the same Row composable with different content based on `currentMode`.

### Back Gesture Handling

```kotlin
// In CanvasScreen composable
BackHandler(enabled = currentMode != AppMode.BROWSE) {
    when (currentMode) {
        AppMode.ANNOTATE -> viewModel.exitAnnotateMode()
        AppMode.EDIT -> viewModel.requestCancelEdit() // shows dialog
        else -> { /* BROWSE: system default back */ }
    }
}
```

### Edit Mode Cancel Confirmation (Resolution R-08)

```kotlin
// When user taps ✕ Cancel in Edit Mode:
fun requestCancelEdit() {
    _uiState.update { it.copy(showCancelDialog = true) }
}

fun confirmCancelEdit() {
    // TODO S02: Revert edit undo stack to snapshot taken at entry
    _uiState.update { it.copy(showCancelDialog = false) }
    exitEditMode(apply = false)
}

fun dismissCancelDialog() {
    _uiState.update { it.copy(showCancelDialog = false) }
}
```

The actual undo stack snapshot/revert is implemented in Session 02. Here, just wire the dialog and the function signatures.

### Integration with EditableTouchImageView

The existing `EditableTouchImageView` handles touch events for photos. In BROWSE mode, it should allow drag-to-reorder. The mode needs to be passed down so it can adjust behavior:

```kotlin
// Pass mode to the view
editableTouchImageView.setAppMode(currentMode)

// Inside EditableTouchImageView:
// BROWSE: existing drag-to-reorder behavior
// ANNOTATE: pass touch events to annotation layer (S03)
// EDIT: existing per-photo editing behavior
```

For now, just add the `setAppMode()` function and store the mode. Touch routing changes come in S03.

## RESOLVED CONFLICTS

**R-08 (Edit Mode Cancel + Undo Stack):**
- Cancel shows confirmation: "Discard all changes?" [Discard] [Keep Editing]
- On Discard: revert edit stack (stub — actual implementation in S02)
- On Done: commit changes (stub — actual implementation in S02)
- Redo stack cleared on Done

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Undo/redo buttons (↩ ↪) | Visible but disabled, `onClick = {}` | S02 |
| FABs (+ and ✏) | Placeholder positions, non-functional | S04 |
| Export button (⬆) | Visible but `onClick = { /* TODO S25 */ }` | S25 |
| Menu (☰) | Visible but `onClick = { /* TODO S23 */ }` | S23 |
| Toolbar content | Empty 56dp containers | S06, S07 |
| Properties (⚙) | Visible in Annotate, `onClick = {}` | S18 |
| Layers (🔲) | Visible in Annotate, `onClick = {}` | S19 |
| Save indicator (●) | Static green dot, no auto-save logic | S24 |

## TEST CRITERIA

1. App launches in BROWSE mode — no accent bar visible
2. Tapping a placeholder ✏ button enters ANNOTATE mode — blue 2dp bar appears
3. Tapping ✕ Done in ANNOTATE returns to BROWSE — bar disappears
4. Long-pressing a photo enters EDIT mode — cyan 2dp bar appears
5. Tapping ✓ Done in EDIT returns to BROWSE
6. Tapping ✕ Cancel in EDIT shows confirmation dialog
7. Confirming "Discard" returns to BROWSE
8. Tapping "Keep Editing" dismisses dialog, stays in EDIT
9. Back gesture in ANNOTATE returns to BROWSE
10. Back gesture in EDIT shows confirmation dialog
11. Top bar title changes per mode: project name (BROWSE), tool name placeholder (ANNOTATE), "Edit: Photo N" (EDIT)
12. Cross-fade animation is visible on mode transition (200ms)
13. Cannot transition ANNOTATE → EDIT directly (no UI path exists)
14. Rotate device during any mode — mode state preserved

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:model` | `com.bcd.technotes.core.model` | `AppMode.kt` | `AppMode` enum |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:feature:canvas` | `CanvasViewModel.kt` | Add `currentMode: StateFlow<AppMode>`, transition functions, `CanvasUiState` |
| `:feature:canvas` | `CanvasScreen.kt` | Add mode-dependent top bar, accent bar, bottom placeholder, BackHandler, cancel dialog |
| `:feature:canvas` | `EditableTouchImageView.kt` | Add `setAppMode()` function, store mode (touch routing deferred to S03) |

---

*Session 01 Blueprint — v1.0*
