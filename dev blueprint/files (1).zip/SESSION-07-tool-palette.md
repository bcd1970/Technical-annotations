# Session 07 — Tool Palette Architecture

## GOAL

Replace the placeholder toolbar from S05 with the full 6-slot tool palette: category tray open/close with spring animation, last-used tool memory per category, Text as direct action (no tray), More as full catalog stub, and long-press for property defaults stub. This session builds the tool selection infrastructure that all drawing sessions (S09–S17) plug into.

## DEPENDS ON

- **S05 (Annotate Chrome)** — Annotate mode shell, toolbar placeholder (56dp pill shell with 6 placeholder slots), `ChromeAutoHideController`, `ActiveTool` state, `activeTool: StateFlow`
- **S03 (Drawing Surface)** — `GestureRouter` that reads `activeTool` to decide gesture behavior

## SPEC REFERENCES

Read before coding:
- `INTERACTION-SPEC.md` §5 (Bottom Tool Palette Architecture — full spec)
- `INTERACTION-SPEC.md` §6 (Text Tool — activation pattern only, not full text implementation)
- `INTERACTION-SPEC.md` §7 (Tool Categories — complete mapping of 50 tools to categories)
- `INTERACTION-SPEC.md` §13 (Properties — long-press access pattern)
- Resolution R-02 (Annotate Toolbar — INTERACTION-SPEC 6-slot layout wins)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `CanvasScreen.kt` | `:feature:canvas` | Annotate mode shows 56dp placeholder toolbar from S05 | Replace placeholder with real `ToolPalette` composable |
| `CanvasViewModel.kt` | `:feature:canvas` | Has `activeTool: StateFlow<ActiveTool>`, `isDrawing`, mode state | Add `activeCategory`, `openTray`, `lastUsedTools` map, tray open/close functions |
| `ActiveTool.kt` | `:core:model` | `sealed class ActiveTool { None, Select, Text, Draw(toolId, toolName) }` | No changes — tool palette sets this state |
| `ChromeAutoHideController` | `:feature:canvas` | Auto-hide logic from S05 | Tray open prevents auto-hide (already has exception slot) |

## DELIVERABLES

### Bottom Toolbar — 6 Slots

1. **Toolbar pill container:**
   - Pill-shaped, 56dp height, 8dp from bottom edge, centered horizontally
   - Background: `Surface` color at 95% opacity, rounded corners (28dp radius), elevation 4dp
   - Width: wraps content with 12dp horizontal padding
   - 6 icon+label slots inside a `Row`

2. **Slot definitions** (per R-02 — INTERACTION-SPEC wins):
   ```
   Slot 1: ╱ Lines     → Category (tray on tap)     — 9 tools
   Slot 2: 📏 Measure  → Category (tray on tap)     — 6 tools
   Slot 3: ○ Shapes    → Category (tray on tap)     — 15 tools (12 + #46 Decorated Path + 2 reserved)
   Slot 4: T Text      → DIRECT ACTION (no tray)    — 1 tool
   Slot 5: ◇ Marks     → Category (tray on tap)     — 7 tools
   Slot 6: ⋯ More      → Full catalog modal (stub)  — all 50 tools
   ```

3. **Slot visual states:**
   - Default: icon (20dp) + label (10sp) stacked vertically, `onSurface` color at 60%
   - Active: filled accent background tint at 15% opacity, icon and label at 100% `onSurface`
   - A slot is "active" when any tool from its category is the current `activeTool`

### Category Tray (Slots 1, 2, 3, 5)

4. **Tray behavior:**
   - Tap a category slot → tray rises above toolbar with 250ms spring animation (`Spring.DampingRatioMediumBouncy`, `Spring.StiffnessLow`)
   - Tray background: elevated surface (8dp elevation), rounded corners, matches toolbar width
   - Content: horizontal `LazyRow` of tool items

5. **Tool items in tray:**
   - Each tool: 48dp × 64dp (icon 24dp + 10sp label below)
   - Scrollable if >5 tools (Shapes has 15 — definitely scrolls)
   - Last-used tool has blue accent ring (2dp border)
   - Tap tool → tray collapses (200ms slide-down), tool activates (`ActiveTool.Draw(toolId, toolName)`)

6. **Tray interaction rules:**
   - Tap same category again → toggle tray closed
   - Tap different category → current tray closes, new tray opens
   - Tap canvas (anywhere outside tray/toolbar) → tray collapses, last-used/pre-selected tool activates
   - Swipe down on tray → collapse without changing tool
   - Tray open → `ChromeAutoHideController` exception active (chrome stays visible)

### Text — Direct Action (Slot 4)

7. **Text tool activation:**
   - Tap "T" → text tool activates IMMEDIATELY. No tray opens.
   - `activeTool` set to `ActiveTool.Text`
   - Top bar center text changes to "Text" (already wired in S05)
   - Slot 4 shows active state (filled accent tint)
   - Actual text placement behavior comes in S12 — for now, toast "Text tool active. Tap canvas to place text. (Coming in S12)"

### More — Full Catalog (Slot 6)

8. **More button:**
   - Tap ⋯ → opens full-screen catalog modal (stub)
   - For now: show a simple full-screen overlay with:
     - ✕ close button (top-left)
     - Title "All Tools"
     - Placeholder grid showing all 50 tool names organized by category
     - Tap any tool → closes modal, activates tool in appropriate category
   - Real catalog with search, domain sections, and drag customization in S27

### Last-Used Tool Memory

9. **Per-category last-used tracking:**
   ```kotlin
   // In CanvasViewModel
   val lastUsedTools: MutableMap<ToolCategory, Int> = mutableMapOf(
       ToolCategory.LINES to 1,      // Default: #01 Straight Line
       ToolCategory.MEASURE to 5,    // Default: #05 Linear Dimension
       ToolCategory.SHAPES to 13,    // Default: #13 Circle
       ToolCategory.MARKS to 40,     // Default: #40 Leader+Text
   )
   ```
   - When a tool is selected from a tray, update `lastUsedTools[category]`
   - When tray opens, pre-select (blue ring) the last-used tool
   - When tray collapses via canvas tap, the pre-selected tool activates
   - Persist across session (in-memory for now — project persistence in S23)

### Long-Press for Properties (Stub)

10. **Long-press detection:**
    - Long-press (400ms) any tool icon in toolbar OR tray → stub action
    - Show toast: "Tool defaults — coming in S18"
    - Real properties sheet in S18 (Properties Sheet System)

### Tool Category Mapping

11. **Complete tool-to-category mapping** (from INTERACTION-SPEC §7):

    **Lines (Slot 1) — 9 tools:**
    #01 Straight Line, #02 Break Zigzag, #03 Break Wave, #04 Stitch Line,
    #08 Grainline Arrow, #09 Zigzag Inline, #10 Coil/Bumps, #11 Wave/Sine,
    #40 Leader+Text

    **Measure (Slot 2) — 6 tools:**
    #05 Linear Dimension, #06 Angular Dimension, #07 Radius/Diameter,
    #41 Tolerance, #25 V-Shape Surface Finish, #43 GD&T FCF

    **Shapes (Slot 3) — 15 tools:**
    #13 Circle, #14 Circle+Text, #15 Circle+Divider, #16 Circle+Crosshairs,
    #17 Concentric, #20 Triangle, #21 Rectangle, #22 Rect+Pattern,
    #23 Labeled Rect, #24 Diamond, #36 Hatching Fill, #39 Revision Cloud,
    #46 Decorated Path (stub), + 2 reserved

    **Text (Slot 4) — 1 tool:**
    Text (direct action, ID = -1 or TEXT constant)

    **Marks (Slot 5) — 7 tools:**
    #19 Split Circle, #12 Parallel Plates, #31 Inline Triangle+Bar,
    #32 Bowtie Valve, #33 Diamond Inline, #35 Arrowhead Modifier,
    #42 Welding Symbol

## DATA MODELS

```kotlin
// New file in :core:model — ToolCategory.kt
enum class ToolCategory(val displayName: String, val icon: String) {
    LINES("Lines", "╱"),
    MEASURE("Measure", "📏"),
    SHAPES("Shapes", "○"),
    TEXT("Text", "T"),
    MARKS("Marks", "◇"),
    MORE("More", "⋯")
}
```

```kotlin
// New file in :core:model — ToolDefinition.kt
data class ToolDefinition(
    val id: Int,
    val name: String,
    val category: ToolCategory,
    val iconResId: Int = 0,    // placeholder — real icons later
    val gestureGroup: GestureGroup = GestureGroup.TWO_POINT
)

enum class GestureGroup {
    TWO_POINT,       // Lines, dimensions
    TAP_PLACE,       // Shapes, circles
    TAP_ON_LINE,     // Marks that attach to existing lines
    DRAG_AREA,       // Hatching, revision cloud
    FREEHAND,        // Freehand drawing
    TEXT,            // Text placement
    WIZARD           // Complex multi-step tools
}
```

```kotlin
// New file in :core:model — ToolRegistry.kt
object ToolRegistry {
    val allTools: List<ToolDefinition> = listOf(
        // Lines
        ToolDefinition(1, "Straight Line", ToolCategory.LINES),
        ToolDefinition(2, "Break Zigzag", ToolCategory.LINES),
        ToolDefinition(3, "Break Wave", ToolCategory.LINES),
        ToolDefinition(4, "Stitch Line", ToolCategory.LINES),
        ToolDefinition(8, "Grainline Arrow", ToolCategory.LINES),
        ToolDefinition(9, "Zigzag Inline", ToolCategory.LINES),
        ToolDefinition(10, "Coil/Bumps", ToolCategory.LINES),
        ToolDefinition(11, "Wave/Sine", ToolCategory.LINES),
        ToolDefinition(40, "Leader+Text", ToolCategory.LINES),
        // Measure
        ToolDefinition(5, "Linear Dimension", ToolCategory.MEASURE, gestureGroup = GestureGroup.TWO_POINT),
        ToolDefinition(6, "Angular Dimension", ToolCategory.MEASURE, gestureGroup = GestureGroup.TWO_POINT),
        ToolDefinition(7, "Radius/Diameter", ToolCategory.MEASURE, gestureGroup = GestureGroup.TWO_POINT),
        ToolDefinition(41, "Tolerance", ToolCategory.MEASURE, gestureGroup = GestureGroup.WIZARD),
        ToolDefinition(25, "Surface Finish", ToolCategory.MEASURE, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(43, "GD&T FCF", ToolCategory.MEASURE, gestureGroup = GestureGroup.WIZARD),
        // Shapes
        ToolDefinition(13, "Circle", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(14, "Circle+Text", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(15, "Circle+Divider", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(16, "Circle+Crosshairs", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(17, "Concentric", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(20, "Triangle", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(21, "Rectangle", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(22, "Rect+Pattern", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(23, "Labeled Rect", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(24, "Diamond", ToolCategory.SHAPES, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(36, "Hatching Fill", ToolCategory.SHAPES, gestureGroup = GestureGroup.DRAG_AREA),
        ToolDefinition(39, "Revision Cloud", ToolCategory.SHAPES, gestureGroup = GestureGroup.DRAG_AREA),
        ToolDefinition(46, "Decorated Path", ToolCategory.SHAPES, gestureGroup = GestureGroup.FREEHAND),
        // Marks
        ToolDefinition(19, "Split Circle", ToolCategory.MARKS, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(12, "Parallel Plates", ToolCategory.MARKS, gestureGroup = GestureGroup.TAP_PLACE),
        ToolDefinition(31, "Inline Triangle", ToolCategory.MARKS, gestureGroup = GestureGroup.TAP_ON_LINE),
        ToolDefinition(32, "Bowtie Valve", ToolCategory.MARKS, gestureGroup = GestureGroup.TAP_ON_LINE),
        ToolDefinition(33, "Diamond Inline", ToolCategory.MARKS, gestureGroup = GestureGroup.TAP_ON_LINE),
        ToolDefinition(35, "Arrowhead Modifier", ToolCategory.MARKS, gestureGroup = GestureGroup.TAP_ON_LINE),
        ToolDefinition(42, "Welding Symbol", ToolCategory.MARKS, gestureGroup = GestureGroup.WIZARD),
    )

    fun toolsForCategory(category: ToolCategory): List<ToolDefinition> =
        allTools.filter { it.category == category }

    fun toolById(id: Int): ToolDefinition? = allTools.find { it.id == id }
}
```

```kotlin
// In CanvasViewModel — new state fields
val activeCategory: StateFlow<ToolCategory?>       // which category's tray is open
val isTrayOpen: StateFlow<Boolean>                 // tray visibility
val lastUsedTools: Map<ToolCategory, Int>           // category → toolId
```

## KEY IMPLEMENTATION DETAILS

### Spring Animation for Tray

```kotlin
// Tray height animation using spring
val trayHeight by animateDpAsState(
    targetValue = if (isTrayOpen) measuredTrayHeight else 0.dp,
    animationSpec = spring(
        dampingRatio = Spring.DampingRatioMediumBouncy,
        stiffness = Spring.StiffnessLow
    )
)
```

**Known pitfall (from SANDBOX-ITERATION-WORKFLOW examples):** `AnimatedVisibility` for tray causes layout measurement jank on first open. Instead, pre-measure tray content height on first composition, cache it, and use `animateDpAsState` with spring spec against the cached height.

### Tray Open/Close State Machine

```
CLOSED → (tap category) → OPEN_FOR_CATEGORY
OPEN_FOR_CATEGORY → (tap same category) → CLOSED
OPEN_FOR_CATEGORY → (tap different category) → OPEN_FOR_NEW_CATEGORY
OPEN_FOR_CATEGORY → (tap tool in tray) → TOOL_ACTIVATED → CLOSED
OPEN_FOR_CATEGORY → (tap canvas) → PRE_SELECTED_ACTIVATED → CLOSED
OPEN_FOR_CATEGORY → (swipe down tray) → CLOSED (no tool change)
```

### Tray Scroll Position

For categories with many tools (Shapes has 15), the `LazyRow` should scroll to show the last-used tool centered in the tray on open. Use `LazyListState.animateScrollToItem()`.

### Toolbar During Chrome Auto-Hide

When `ChromeAutoHideController` triggers hide during drawing:
- Toolbar slides down to show only 4dp accent line (same as S05 behavior)
- If tray is open → tray also hides (200ms fade)
- On draw end → toolbar restores, but tray stays closed (user must re-open)

## RESOLVED CONFLICTS

**R-02:** Annotate toolbar uses INTERACTION-SPEC 6-slot definition (Lines, Measure, Shapes, Text, Marks, More). NOT the FINAL-spec 5-slot definition.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| All drawing tool behaviors | Toast "Tool active. Drawing coming in S09–S17" when canvas tapped with tool active | S09–S17 |
| Text tool placement | Toast "Text placement coming in S12" | S12 |
| More catalog (full) | Simple grid of tool names, no search/domains | S27 (More Catalog + Search) |
| Long-press properties | Toast "Tool defaults coming in S18" | S18 (Properties Sheet) |
| Tool icons | Use Material Icons or simple Unicode as placeholders | S27+ (catalog populates real icons) |

## TEST CRITERIA

1. **Toolbar replaces placeholder:** Annotate mode shows 6-slot pill toolbar with icons and labels (not the S05 placeholder toast slots).
2. **Tap Lines category:** Tray opens with spring animation showing 9 line tools.
3. **Tap tool in tray:** Tool activates, tray collapses (200ms), top bar shows tool name, slot 1 highlighted as active.
4. **Tap same category again:** Tray toggles closed.
5. **Tap different category:** Current tray closes, new tray opens.
6. **Tap canvas with tray open:** Tray collapses, pre-selected (last-used) tool activates.
7. **Swipe down on tray:** Tray closes, no tool change.
8. **Last-used memory:** Select Zigzag from Lines → close tray → reopen Lines → Zigzag has blue ring.
9. **Text direct action:** Tap T → text tool activates immediately, NO tray opens, slot 4 highlighted.
10. **More catalog stub:** Tap ⋯ → full-screen overlay with tool list. Tap tool → modal closes, tool activates.
11. **Shapes scrolls:** Tap Shapes → tray opens with 15 tools in scrollable row. Can scroll to see all.
12. **Long-press stub:** Long-press any tool icon → toast shown.
13. **Auto-hide with tray:** Tray open → start draw gesture → tray + toolbar hide. End draw → toolbar restores, tray stays closed.
14. **Active state visual:** Selected tool's category slot shows filled accent background.
15. **Rotate device:** Tool palette state survives rotation. Active tool preserved.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:model` | `com.bcd.technotes.core.model` | `ToolCategory.kt` | Category enum |
| `:core:model` | `com.bcd.technotes.core.model` | `ToolDefinition.kt` | Tool data class + GestureGroup enum |
| `:core:model` | `com.bcd.technotes.core.model` | `ToolRegistry.kt` | Static registry of all 50 tools |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `ToolPalette.kt` | Main toolbar composable (6 slots) |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `CategoryTray.kt` | Tray composable with spring animation |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `ToolCatalogModal.kt` | Full-screen catalog overlay (stub) |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:feature:canvas` | `CanvasViewModel.kt` | Add `activeCategory`, `isTrayOpen`, `lastUsedTools` state. Add `openTray(category)`, `closeTray()`, `selectTool(toolId)`, `selectText()` functions. |
| `:feature:canvas` | `CanvasScreen.kt` | Replace S05 toolbar placeholder with `ToolPalette` composable. Add `ToolCatalogModal` overlay. |
| `:feature:canvas` | `ChromeAutoHideController` | Add tray-open exception: when `isTrayOpen = true`, prevent auto-hide. On hide trigger while tray open → close tray first. |

---

*Session 07 Blueprint — v1.0*
