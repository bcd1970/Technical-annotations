# Session 09 — Two-Point Lines + Selection

## GOAL

Implement the drawing engine for two-point primitives (Group A): the gesture flow (tap point A → drag to point B), live preview with snap integration, and concrete renderers for 9 line tools (#01 Straight Line, #02 Break Zigzag, #03 Break Wave, #04 Stitch Line, #08 Grainline Arrow, #09 Zigzag Inline, #10 Coil/Bumps, #11 Wave/Sine). Also implement the universal selection system: tap-to-select, move by drag, delete by swipe-up, and the context bar from S05 wired to real actions. Leader+Text (#40) is deferred to S15.

## DEPENDS ON

- **S07 (Tool Palette)** — `ToolPalette`, `ToolRegistry`, `ActiveTool.Draw(toolId)`, tool activation from Lines category tray
- **S08 (Snap Engine)** — `SnapEngine.findSnap()`, `SnapResult`, snap HUD rendering, haptic feedback, magnifier loupe, input mode detection
- **S03 (Drawing Surface)** — `EditableTouchImageView`, `DrawableElement` interface, `GestureRouter`, `screenToImage()`, `imageToScreen()`, annotations list, `selectedElement`, `activeDrawing`
- **S02 (Undo/Redo)** — `UndoManager` annotate stack for element add/move/delete
- **S05 (Annotate Chrome)** — `AnnotationContextBar` composable, chrome auto-hide during draw

## SPEC REFERENCES

Read before coding:
- `FINAL-complete-implementation-spec.md` §4 (Group A: Two-Point Primitives — all 10 data classes + render specs)
- `FINAL-complete-implementation-spec.md` §1 (Global Architecture — Gesture Vocabulary table, Input Modes)
- `GRAPHIC-ELEMENT-EDITING-SPEC.md` §4 (Lines & Connectors — dash patterns, stroke properties)
- `INTERACTION-SPEC.md` §8 (Gesture Routing — draw tool gesture flow)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-05 (Progressive Disclosure), P-09 (Snap Engine integration)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `EditableTouchImageView.kt` | `:feature:canvas` | Touch handling, annotation rendering, snap integration from S08 | Add two-point draw gesture handler. Render live preview. Add selection/move/delete gestures. |
| `GestureRouter.kt` | `:core:drawing` | Routes by mode+tool from S03 | Draw tool route now calls `TwoPointDrawHandler` |
| `DrawableElement.kt` | `:core:drawing` | Interface from S03 — `draw()`, `hitTest()`, `getEndpoints()` etc. | Implement for each line type |
| `SnapEngine.kt` | `:core:drawing` | Snap detection from S08 | Called during drag with anchor point for angle constraint |
| `CanvasViewModel.kt` | `:feature:canvas` | Has `annotations`, `selectedElement`, `activeDrawing`, `activeTool` | Add element CRUD operations: `addElement()`, `selectElement()`, `moveElement()`, `deleteElement()` |
| `UndoManager.kt` | `:core:undo` | Annotate undo stack from S02 | Push on add/move/delete |
| `ToolRegistry.kt` | `:core:model` | Lines category tools from S07 | Lookup tool definition to determine render type |
| `AnnotationContextBar` | `:feature:canvas` | Context bar from S05 | Wire delete action, color quick-change, stroke width preset |

## DELIVERABLES

### Two-Point Draw Gesture Handler

1. **`TwoPointDrawHandler` class** in `:core:drawing`:
   ```
   STATE MACHINE:
   IDLE → (ACTION_DOWN on canvas with draw tool) → ANCHOR_SET
   ANCHOR_SET → (ACTION_MOVE >10dp) → DRAGGING
   DRAGGING → (ACTION_MOVE) → update endpoint + snap + live preview
   DRAGGING → (ACTION_UP) → PLACED → element finalized → push to undo → IDLE
   ANCHOR_SET → (ACTION_UP <200ms, <10dp) → TAP_START (anchor point set, waiting for second tap)
   TAP_START → (ACTION_DOWN + ACTION_UP <200ms) → PLACED (two-tap mode)
   TAP_START → (timeout 3s or tool change) → CANCELLED → IDLE
   ```

2. **Drag mode vs two-tap mode:**
   - DRAG: press down at A → drag to B → release. Common on touch devices.
   - TWO-TAP: tap A → green pulsing anchor dot appears → tap B → line drawn. Preferred for precision.
   - Both modes produce the same element. Snap applies in both.

3. **Live preview during drag/between taps:**
   - Thin dashed line from anchor to current position (1dp, 50% opacity)
   - Snap crosshairs shown if snapping (from S08 SnapHUD)
   - Angle guide: faint arc showing current angle when near snap angle

4. **Anchor dot:**
   - Green (#4CAF50), pulsing (1.0→1.3× scale, 1s cycle), 6dp radius
   - Shown at point A after first tap (in two-tap mode) or on initial press (in drag mode)
   - Disappears when element is finalized

### Line Renderers (9 tools)

Each tool gets a concrete `DrawableElement` implementation in `:core:drawing`:

5. **#01 — `StraightLineElement`:**
   - Renders straight line from start to end
   - Supports 14 dash types via `Paint.setPathEffect(DashPathEffect(intervals, 0f))`
   - Supports arrowheads at both endpoints (for now: use CLOSED_FILLED placeholder — full arrowhead system in S10)
   - Properties: `dashType`, `strokeWidth`, `color`, `startArrow`, `endArrow`

6. **#02 — `BreakZigzagElement`:**
   - Line A → break start, zigzag peaks (5-7 triangular peaks, amplitude = strokeWidth × 4), line break end → B
   - `breakPosition: Float` (0.0–1.0, default 0.5 = centered)
   - Zigzag computed as alternating peaks perpendicular to line direction

7. **#03 — `BreakWaveElement`:**
   - Line A → bezier wave (2-3 control points), line → B
   - Same `breakPosition` parameter as zigzag
   - Wave rendered with `cubicTo()` on `Path`

8. **#04 — `StitchLineElement`:**
   - 7 stitch variants: SINGLE_TOP, DOUBLE_TOP, ZIGZAG, CHAIN, BLIND, OVERLOCK, BACKSTITCH
   - Each rendered with unique `DashPathEffect` or custom `Path` pattern
   - DOUBLE_TOP: two parallel lines offset 1-2dp apart
   - CHAIN: series of small ellipses along path
   - OVERLOCK: looping wave pattern

9. **#08 — `GrainlineArrowElement`:**
   - Always double-headed arrow (both ends get arrowheads)
   - Label centered above line ("GRAIN", "STRETCH", "BIAS 45°", "WARP")
   - Snaps to 0°/45°/90° angles preferentially
   - Text rendered in image-space, size proportional to line length

10. **#09 — `ZigzagInlineElement`:**
    - Zigzag pattern between start and end (5-7 peaks)
    - Peak count auto-calculated from distance
    - Used for electronics resistor (ANSI style)

11. **#10 — `CoilBumpsElement`:**
    - Series of semicircular bumps (3-7) between start and end
    - `coreType`: AIR (basic), IRON (adds parallel lines through bumps), VARIABLE (adds diagonal arrow)
    - Each bump rendered with `arcTo()` on `Path`

12. **#11 — `WaveSineElement`:**
    - Sine wave between start and end
    - `amplitude` and `frequency` adjustable (defaults computed from distance)
    - Rendered with cubic bezier approximation of sine curve

### Universal Selection System

13. **Tap-to-select:**
    - When `ActiveTool == Select` or no draw in progress:
    - Tap on canvas → `hitTest()` all visible elements (front-to-back, topmost wins)
    - Hit radius: `strokeWidth + 12dp` for lines (converted to image-space)
    - If hit → `selectedElement` updated, `AnnotationContextBar` appears
    - If miss → `selectedElement = null`, context bar hides

14. **Move by drag:**
    - With element selected, one-finger drag on the element → move
    - Compute delta in image-space: `newPos - oldPos` per ACTION_MOVE
    - Update element start/end points by delta
    - Snap applies to the dragged position (snap the nearest endpoint of the moving element)
    - On drag end → push move action to undo stack

15. **Delete:**
    - **Swipe up on selected element** (drag >80dp upward, velocity >500dp/s) → delete with 200ms fade-out animation
    - **Context bar 🗑 button** → immediate delete
    - Both push delete action to undo stack

16. **Context bar wiring** (from S05):
    - `AnnotationContextBar` now functional:
      ```
      ┌──────────────────────────────────────────────┐
      │  ● color  │  1px  2px  [3px]  │  ⧉  🗑  │  ⚙  │
      └──────────────────────────────────────────────┘
      ```
    - **● color**: cycle through recent 4 colors. Real color picker in S18.
    - **Stroke width presets**: 1px, 2px, 3px quick toggles. Applies immediately.
    - **⧉ Duplicate**: copy selected element, offset +10dp,+10dp, push to undo.
    - **🗑 Delete**: delete selected element, push to undo.
    - **⚙ Properties**: stub toast "Properties coming in S18"

### DashType System

17. **14 dash types** (from GRAPHIC-ELEMENT-EDITING-SPEC §4):
    ```kotlin
    enum class DashType(val intervals: FloatArray?) {
        // Standard (7)
        SOLID(null),
        DASHED(floatArrayOf(12f, 6f)),
        CHAIN(floatArrayOf(24f, 4f, 4f, 4f)),
        PHANTOM(floatArrayOf(24f, 4f, 4f, 4f, 4f, 4f)),
        DOTTED(floatArrayOf(2f, 4f)),
        CHAIN_DOUBLE(floatArrayOf(24f, 4f, 4f, 4f, 4f, 4f)),
        
        // Stitch (7)
        STITCH_SINGLE_TOP(floatArrayOf(6f, 4f)),
        STITCH_DOUBLE_TOP(null),   // special: two parallel lines
        STITCH_ZIGZAG(null),       // special: zigzag path effect
        STITCH_CHAIN(null),        // special: ellipse stamps
        STITCH_BLIND(floatArrayOf(1f, 6f)),
        STITCH_OVERLOCK(null),     // special: looping wave
        STITCH_BACKSTITCH(floatArrayOf(8f, 2f, 2f, 2f));
        
        fun toPathEffect(strokeWidth: Float, dashScale: Float = 1f): PathEffect? {
            val scaled = intervals?.map { it * dashScale }?.toFloatArray()
            return scaled?.let { DashPathEffect(it, 0f) }
        }
    }
    ```

### Drawing Element Base Implementation

18. **Abstract base class** for shared line behavior:
    ```kotlin
    abstract class TwoPointElement(
        override val id: String,
        var start: PointF,
        var end: PointF,
        var strokeWidth: Float,
        var color: Int,
        var dashType: DashType,
        var layer: String
    ) : DrawableElement {
        
        override fun getEndpoints() = listOf(start, end)
        override fun getMidpoints() = listOf(PointF((start.x+end.x)/2, (start.y+end.y)/2))
        override fun getLineSegments() = listOf(start to end)
        
        override fun hitTest(point: PointF, hitRadius: Float): Boolean {
            return distanceToLineSegment(point, start, end) <= hitRadius
        }
        
        override fun getBoundingBox(): RectF { /* min/max of start, end + stroke */ }
    }
    ```

## DATA MODELS

```kotlin
// In :core:drawing — new files per element type
// StraightLineElement.kt, BreakZigzagElement.kt, BreakWaveElement.kt,
// StitchLineElement.kt, GrainlineArrowElement.kt, ZigzagInlineElement.kt,
// CoilBumpsElement.kt, WaveSineElement.kt

// In :core:drawing — TwoPointDrawHandler.kt
class TwoPointDrawHandler(
    private val snapEngine: SnapEngine,
    private val onPreview: (DrawableElement?) -> Unit,
    private val onCommit: (DrawableElement) -> Unit
) { /* state machine as described */ }

// In :core:drawing — SelectionHandler.kt
class SelectionHandler(
    private val elements: () -> List<DrawableElement>,
    private val onSelect: (DrawableElement?) -> Unit,
    private val onMove: (DrawableElement, PointF) -> Unit,
    private val onDelete: (DrawableElement) -> Unit
) { /* hit-test, move, swipe-delete logic */ }
```

## KEY IMPLEMENTATION DETAILS

### Rendering Order

Elements render in this order (back to front):
1. Photo bitmap (existing)
2. Grid overlay (from S08, if visible)
3. Placed elements on locked layers (dimmed if layer locked)
4. Placed elements on active layer
5. Active drawing preview (live line being drawn)
6. Selection handles on selected element
7. Snap HUD (crosshairs + label)
8. Magnifier loupe (if active)
9. Anchor dot (if in two-tap wait state)

### Scale-Aware Rendering

From S03's `RenderUtils`:
- `strokeWidth` is in image-space. Render at `strokeWidth * zoom`, clamped to min 0.75px screen.
- Text for Grainline labels: image-space size, rendered through viewMatrix.
- Hit-test radius: `(strokeWidth/2 + 12.dp.toImageSpace(zoom))`.

### Creating Elements from Tool ID

```kotlin
fun createElementForTool(toolId: Int, start: PointF, end: PointF, defaults: ToolDefaults): DrawableElement {
    return when (toolId) {
        1 -> StraightLineElement(UUID(), start, end, defaults.strokeWidth, defaults.color, defaults.dashType, defaults.layer)
        2 -> BreakZigzagElement(UUID(), start, end, 0.5f, defaults.strokeWidth, defaults.color, defaults.layer)
        3 -> BreakWaveElement(UUID(), start, end, 0.5f, defaults.strokeWidth, defaults.color, defaults.layer)
        4 -> StitchLineElement(UUID(), start, end, StitchType.SINGLE_TOP, defaults.strokeWidth, defaults.color, defaults.layer)
        8 -> GrainlineArrowElement(UUID(), start, end, "GRAIN", defaults.strokeWidth, defaults.color, defaults.layer)
        9 -> ZigzagInlineElement(UUID(), start, end, defaults.strokeWidth, defaults.color, defaults.layer)
        10 -> CoilBumpsElement(UUID(), start, end, CoreType.AIR, defaults.strokeWidth, defaults.color, defaults.layer)
        11 -> WaveSineElement(UUID(), start, end, defaults.strokeWidth, defaults.color, defaults.layer)
        else -> StraightLineElement(UUID(), start, end, defaults.strokeWidth, defaults.color, DashType.SOLID, defaults.layer)
    }
}
```

### Arrowhead Placeholder

For tools that support arrowheads (#01, #08), store `startArrow` and `endArrow` as `ArrowStyle` enums. For rendering in this session, only draw `CLOSED_FILLED` (simple filled triangle):
```kotlin
fun drawPlaceholderArrow(canvas: Canvas, tip: PointF, angle: Float, size: Float, paint: Paint) {
    val path = Path()
    val headLength = maxOf(size * 3f, 10f)
    val halfWidth = maxOf(size * 1.5f, 3.5f)
    // Triangle pointing in `angle` direction at `tip`
    path.moveTo(tip.x, tip.y)
    path.lineTo(tip.x - headLength * cos(angle) + halfWidth * sin(angle),
                tip.y - headLength * sin(angle) - halfWidth * cos(angle))
    path.lineTo(tip.x - headLength * cos(angle) - halfWidth * sin(angle),
                tip.y - headLength * sin(angle) + halfWidth * cos(angle))
    path.close()
    canvas.drawPath(path, paint.apply { style = Paint.Style.FILL })
}
```

Full arrowhead system (20 styles) comes in S10.

## RESOLVED CONFLICTS

No new conflicts for this session. All line specs come from FINAL-complete-implementation-spec.md §4 which is the authority for drawing primitives.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Leader+Text (#40) | Listed in Lines tray but shows toast "Coming in S15" | S15 (Leader + Text) |
| Full arrowhead system (20 styles) | Only CLOSED_FILLED rendered. `ArrowStyle` enum exists but most styles render as CLOSED_FILLED | S10 (Arrowhead Renderer) |
| Chain-continue mode | Ghost extends from last endpoint. For now: no chaining — each line is independent | Later (part of line workflow polish) |
| Context bar ⚙ Properties | Shows toast | S18 (Properties Sheet) |
| Context bar color picker | Cycles through 4 preset colors | S18 (full color picker) |

## TEST CRITERIA

1. **Draw straight line (drag):** Press → drag → release. Line appears from A to B. Correct color and stroke width.
2. **Draw straight line (two-tap):** Tap A → green anchor dot. Tap B → line drawn. Anchor dot disappears.
3. **Live preview:** During drag, dashed preview line follows finger/stylus.
4. **Snap during draw:** Drag near an angle constraint (e.g., ~44°) → line snaps to 45°. Crosshair + "∠ 45°" label visible.
5. **Break zigzag:** Select #02. Draw → zigzag break in middle of line.
6. **Break wave:** Select #03. Draw → smooth wave break in middle.
7. **Stitch line:** Select #04. Draw → stitch pattern visible. Can switch stitch type (via future properties, for now uses default SINGLE_TOP).
8. **Grainline arrow:** Select #08. Draw → double-headed arrow with "GRAIN" label above.
9. **Zigzag inline:** Select #09. Draw → zigzag pattern between endpoints.
10. **Coil/bumps:** Select #10. Draw → semicircular bumps.
11. **Wave/sine:** Select #11. Draw → sine wave.
12. **Select element:** With Select tool (or no tool active), tap on a placed line → selected (context bar appears).
13. **Move element:** Drag selected element → moves. Releases → undo entry created.
14. **Delete (swipe-up):** Swipe up on selected element → deletes with fade animation.
15. **Delete (context bar):** Tap 🗑 → element deleted.
16. **Duplicate (context bar):** Tap ⧉ → copy appears offset +10dp.
17. **Undo add:** Draw line → undo → line removed. Redo → line restored.
18. **Undo move:** Move element → undo → element returns to original position.
19. **Undo delete:** Delete element → undo → element restored.
20. **Hit-test accuracy:** Tap 1dp away from a 2dp stroke line → selected. Tap 20dp away → not selected.
21. **Multiple elements:** Draw 5 different line types. All render correctly. Can select any.
22. **Rotate device:** All elements survive rotation. Positions correct.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `TwoPointElement.kt` | Abstract base for all two-point line elements |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `StraightLineElement.kt` | #01 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `BreakZigzagElement.kt` | #02 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `BreakWaveElement.kt` | #03 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `StitchLineElement.kt` | #04 renderer (7 stitch types) |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `GrainlineArrowElement.kt` | #08 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `ZigzagInlineElement.kt` | #09 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `CoilBumpsElement.kt` | #10 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `WaveSineElement.kt` | #11 renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `TwoPointDrawHandler.kt` | Gesture state machine for two-point draw |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `SelectionHandler.kt` | Universal select/move/delete logic |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `ElementFactory.kt` | Creates DrawableElement from toolId + geometry |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `DashType.kt` | DashType enum with 14 patterns |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:feature:canvas` | `EditableTouchImageView.kt` | Add `TwoPointDrawHandler` integration: on draw gesture with two-point tool → delegate to handler. Add `SelectionHandler` integration. Render live preview, anchor dot. |
| `:feature:canvas` | `CanvasViewModel.kt` | Add `addElement()`, `deleteElement()`, `moveElement()`, `duplicateElement()`. Wire undo for each. Provide `ToolDefaults` (current color, stroke width, layer). |
| `:feature:canvas` | `AnnotationContextBar` (from S05) | Wire ● color cycling, stroke width presets, ⧉ duplicate, 🗑 delete to ViewModel functions. |
| `:core:drawing` | `GestureRouter.kt` | When `ActiveTool.Draw` with a Lines-category tool → route to `TwoPointDrawHandler`. When `ActiveTool.Select` → route to `SelectionHandler`. |
| `:core:drawing` | `DrawableElement.kt` | Ensure `getEndpoints()`, `getMidpoints()`, `getLineSegments()` are available for snap integration. |

### Unit Tests

| Module | Test File | What It Tests |
|--------|-----------|--------------|
| `:core:drawing` | `StraightLineElementTest.kt` | `hitTest()` at various distances, `getEndpoints()`, `getMidpoints()`, rendering doesn't crash |
| `:core:drawing` | `TwoPointDrawHandlerTest.kt` | State machine: IDLE→ANCHOR→DRAGGING→PLACED. Two-tap flow. Cancel/timeout. |
| `:core:drawing` | `DashTypeTest.kt` | All 14 dash types produce valid PathEffect (or null for special types). Scale factor works. |

---

*Session 09 Blueprint — v1.0*
