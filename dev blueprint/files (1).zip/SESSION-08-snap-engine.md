# Session 08 — Snap Engine

## GOAL

Implement the complete snap system: grid snap, angle constraint, endpoint/midpoint/intersection/perpendicular/parallel snapping with priority-based resolution, visual feedback (cyan crosshairs + type label), haptic feedback, grid overlay rendering, magnifier loupe for finger input, stylus hover preview, and the snap toggle in the Annotate mode top bar. This session builds the precision infrastructure that all drawing tools (S09–S17) consume.

## DEPENDS ON

- **S03 (Drawing Surface)** — `EditableTouchImageView` with `viewMatrix`, `inverseMatrix`, `screenToImage()`, `imageToScreen()`, `GestureRouter`, `isDrawing` state, `DrawableElement` interface, annotation list
- **S05 (Annotate Chrome)** — Annotate mode top bar with "Snap 45°" / "Snap OFF" placeholder text (now make functional)

## SPEC REFERENCES

Read before coding:
- `FINAL-complete-implementation-spec.md` §1 (Global Architecture — Snap Engine section, Input Modes, Gesture Vocabulary)
- `INTERACTION-SPEC.md` §8 (Gesture Vocabulary & Routing — snap feedback during draw)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-08 (Input Mode Detection), P-09 (Snap Engine thresholds)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `EditableTouchImageView.kt` | `:feature:canvas` | Touch handling, `screenToImage()`, gesture routing from S03 | Integrate snap detection into ACTION_MOVE during draw. Render snap HUD in `onDraw()`. |
| `CanvasViewModel.kt` | `:feature:canvas` | Has `activeTool`, `annotations`, `isDrawing` | Add `snapEnabled`, `snapResult` state. Wire snap toggle to top bar. |
| `GestureRouter.kt` | `:core:drawing` | Routes one-finger touches by mode+tool from S03 | Snap modifies the output point of draw gestures (snapped position replaces raw touch). |
| `DrawableElement.kt` | `:core:drawing` | Annotation rendering interface from S03 | Snap queries elements for endpoints, midpoints, paths (for intersection/perpendicular). |
| `AnnotateTopBar` | `:feature:canvas` | Has "Snap 45°" placeholder text from S05 | Make functional: tap toggles snap on/off, text reflects state. |

## DELIVERABLES

### SnapEngine Core

1. **`SnapEngine` class** in `:core:drawing` — pure Kotlin, no Android dependencies (testable with JVM):

   ```kotlin
   class SnapEngine {
       var isEnabled: Boolean = true
       var gridSpacing: Float = 5f  // dp, converted to image-space at call site
       
       // Snap thresholds (in image-space pixels, caller converts from dp using zoom)
       var gridSnapRadius: Float = 5f
       var angleSnapDegrees: List<Float> = listOf(0f, 15f, 30f, 45f, 60f, 75f, 90f, 105f, 120f, 135f, 150f, 165f, 180f)
       var endpointSnapRadius: Float = 12f
       var midpointSnapRadius: Float = 12f
       var intersectionSnapRadius: Float = 12f
       var perpendicularSnapRadius: Float = 8f
       var parallelSnapRadius: Float = 8f
       
       /**
        * Given a candidate point (in image-space) and the existing elements on canvas,
        * find the best snap target.
        *
        * @param candidatePoint  raw touch position converted to image-space
        * @param anchorPoint     start point of current draw (for angle constraint), null if no anchor
        * @param elements        all placed annotations on canvas
        * @param zoom            current zoom level (thresholds scale with 1/zoom)
        * @return SnapResult — snapped point + type, or null if no snap
        */
       fun findSnap(
           candidatePoint: PointF,
           anchorPoint: PointF?,
           elements: List<DrawableElement>,
           zoom: Float
       ): SnapResult?
   }
   ```

2. **Snap priority order** (highest priority wins when multiple snaps are within threshold):
   ```
   1. Endpoint     (existing element start/end points)
   2. Intersection  (where two element paths cross)
   3. Midpoint      (center of element segments)
   4. Perpendicular (90° from nearest existing line)
   5. Parallel      (parallel to nearest existing line)
   6. Grid          (snap to grid spacing intervals)
   7. Angle         (constrain to angle increments from anchor)
   ```

3. **`SnapResult` data class:**
   ```kotlin
   data class SnapResult(
       val snappedPoint: PointF,        // final position to use (image-space)
       val snapType: SnapType,          // which snap rule fired
       val label: String,               // display label: "● End", "✕ Int", "◆ Mid", "⊥ Perp", "∥ Para", "# Grid", "∠ 45°"
       val referenceElement: String? = null  // ID of element that triggered snap (for highlighting)
   )
   
   enum class SnapType {
       ENDPOINT, INTERSECTION, MIDPOINT, PERPENDICULAR, PARALLEL, GRID, ANGLE, NONE
   }
   ```

### Snap Detection Algorithms

4. **Endpoint snap:**
   - For each `DrawableElement`, query `getEndpoints(): List<PointF>` (new interface method)
   - Find closest endpoint within `endpointSnapRadius / zoom`
   - Return snapped point = endpoint position

5. **Intersection snap:**
   - For each pair of elements, compute path intersections
   - Implementation: line-line intersection for straight elements
   - Find closest intersection within `intersectionSnapRadius / zoom`
   - Note: for initial implementation, only handle line-line intersections. Curve-line intersections deferred.

6. **Midpoint snap:**
   - For each `DrawableElement`, query `getMidpoints(): List<PointF>`
   - Lines: midpoint of segment. Circles: 4 cardinal points. Rectangles: midpoints of sides.
   - Find closest midpoint within `midpointSnapRadius / zoom`

7. **Perpendicular snap:**
   - For each existing line element, compute the perpendicular projection of `candidatePoint` onto the line
   - If the projection lies on the segment and the angle from `anchorPoint` to projection is within 2° of 90°, snap
   - Within `perpendicularSnapRadius / zoom`

8. **Parallel snap:**
   - For each existing line element, check if the current draw direction (anchor → candidate) is within 2° of the line's angle
   - If so, snap to the nearest grid-aligned parallel position
   - Within `parallelSnapRadius / zoom`

9. **Grid snap:**
   - Quantize `candidatePoint.x` and `.y` to nearest `gridSpacing` multiple
   - If distance to grid point < `gridSnapRadius / zoom`, snap

10. **Angle snap (constraint):**
    - Requires `anchorPoint` (start of current two-point draw)
    - Compute angle from anchor to candidate: `atan2(dy, dx)`
    - Find nearest angle in `angleSnapDegrees` list
    - Snap candidate to point at same distance but at the snapped angle
    - This constrains the line direction without moving the point to a different location

### DrawableElement Interface Extensions

11. **New methods on `DrawableElement` interface** (S03 created the base interface):
    ```kotlin
    interface DrawableElement {
        // ... existing methods from S03 ...
        
        /** All snap-relevant endpoints (start, end of lines; center of shapes). */
        fun getEndpoints(): List<PointF> = emptyList()
        
        /** Midpoints of segments or cardinal points of shapes. */
        fun getMidpoints(): List<PointF> = emptyList()
        
        /** Get the line segments of this element for intersection/perpendicular/parallel computation. */
        fun getLineSegments(): List<Pair<PointF, PointF>> = emptyList()
    }
    ```

### Visual Feedback — Snap HUD

12. **Cyan crosshairs** at snap point:
    - Rendered in screen-space (not affected by viewMatrix zoom)
    - 12dp arm length, 1.5dp stroke width, color `#00BCD4` (cyan)
    - Small circle (3dp radius) at intersection
    - Only visible when snap is active (`snapResult != null`)

13. **Snap type label** near cursor:
    - Positioned 24dp above + 16dp right of the snap crosshairs
    - Background: dark semi-transparent pill (80% black, rounded corners)
    - Text: white, 10sp, monospace font
    - Labels: "● End", "✕ Int", "◆ Mid", "⊥ Perp", "∥ Para", "# Grid", "∠ 45°"
    - Appears with 100ms fade-in, disappears with 100ms fade-out on snap disengage

14. **Reference element highlight:**
    - When snap engages to an endpoint/midpoint/intersection of an existing element, that element briefly pulses with cyan tint (150ms pulse, 2 cycles)
    - Uses `referenceElement` ID from `SnapResult`

### Haptic Feedback

15. **Haptic events:**
    - `HapticFeedbackConstants.CLOCK_TICK` on snap engage (transition from no-snap to snap)
    - `HapticFeedbackConstants.CONFIRM` on snap release (when drawing completes at a snapped position)
    - No haptic on continuous snap hold (only fires on engage transition)
    - Track previous snap state to detect transitions

### Grid Overlay Rendering

16. **Grid lines on canvas:**
    - Rendered in `onDraw()` BELOW annotations but ABOVE the photo
    - Light gray lines (#CCCCCC at 20% opacity) at `gridSpacing` intervals
    - Computed in image-space, rendered through `viewMatrix`
    - Only render lines within the visible viewport (compute bounds from `inverseMatrix`)
    - Grid visibility toggleable via project settings (stored in ViewModel)
    - Grid adapts to zoom: when zoomed in far enough that grid lines are <8px apart on screen, double the spacing. When zoomed out far enough that grid lines are >100px apart, halve the spacing.

### Magnifier Loupe (Finger Input)

17. **Magnifier loupe for finger input:**
    - Shown when `MotionEvent.getToolType(0) == TOOL_TYPE_FINGER` and finger held >150ms during draw
    - Circular loupe: 80dp diameter, 2.5× magnification
    - Position: 60dp ABOVE the touch point (so finger doesn't occlude the magnified area)
    - Content: magnified view of the canvas area around the touch point
    - Border: 2dp white border with subtle shadow
    - Crosshair at center of loupe showing the exact point
    - Disappears immediately on finger-up
    - Implementation: `Canvas.drawBitmapMesh()` or capture bitmap region + scale

### Stylus Hover Preview

18. **Stylus hover crosshair:**
    - Shown on `ACTION_HOVER_MOVE` when `getToolType(0) == TOOL_TYPE_STYLUS`
    - Light crosshair at hover position (smaller than snap crosshair: 8dp arms, 1dp stroke, 40% opacity)
    - Shows before touch-down so user can see where they'll start drawing
    - Disappears on `ACTION_HOVER_EXIT` or `ACTION_DOWN`

### Input Mode Detection (P-08)

19. **Finger vs Stylus detection:**
    ```kotlin
    when (event.getToolType(0)) {
        TOOL_TYPE_FINGER -> {
            snapEngine.endpointSnapRadius = 12f.dpToImageSpace(zoom)
            snapEngine.gridSnapRadius = 5f.dpToImageSpace(zoom)
            showMagnifier = true
            showHoverPreview = false
        }
        TOOL_TYPE_STYLUS -> {
            snapEngine.endpointSnapRadius = 8f.dpToImageSpace(zoom)
            snapEngine.gridSnapRadius = 3f.dpToImageSpace(zoom)
            showMagnifier = false
            showHoverPreview = true
            // Palm rejection: ignore simultaneous TOOL_TYPE_FINGER events
        }
    }
    ```

### Snap Toggle in Top Bar

20. **Snap toggle wired to Annotate top bar:**
    - S05 has placeholder text "Snap 45°" / "Snap OFF" in the center-right of the top bar
    - Now make it functional: tap text → toggle `snapEngine.isEnabled`
    - Text updates: "Snap 45°" when enabled (showing the angle increment), "Snap OFF" when disabled
    - Optional: long-press snap toggle → quick settings popup for snap angle (15°/30°/45°/90°). Stub for now — just toggle on/off.

## DATA MODELS

```kotlin
// New file in :core:drawing — SnapEngine.kt
class SnapEngine { /* as described in deliverable #1 */ }

// New file in :core:drawing — SnapResult.kt
data class SnapResult(
    val snappedPoint: PointF,
    val snapType: SnapType,
    val label: String,
    val referenceElement: String? = null
)

enum class SnapType {
    ENDPOINT, INTERSECTION, MIDPOINT, PERPENDICULAR, PARALLEL, GRID, ANGLE, NONE
}

// New file in :core:drawing — InputMode.kt
enum class InputMode {
    FINGER, STYLUS
}

data class InputModeConfig(
    val hitTargetSize: Float,     // dp
    val snapAggressiveness: Float, // multiplier on snap radii
    val showMagnifier: Boolean,
    val showHoverPreview: Boolean,
    val usePressure: Boolean
)
```

```kotlin
// In CanvasViewModel — new state fields
val snapEnabled: StateFlow<Boolean>
val snapResult: StateFlow<SnapResult?>
val showGrid: StateFlow<Boolean>
val inputMode: StateFlow<InputMode>
val showMagnifier: StateFlow<Boolean>
```

## KEY IMPLEMENTATION DETAILS

### Threshold Scaling with Zoom

All snap thresholds are in dp, but snapping operates in image-space. Convert:
```kotlin
fun Float.dpToImageSpace(zoom: Float): Float = this * density / zoom
```
This means that as the user zooms in, snap thresholds get tighter (more precise). As they zoom out, thresholds get wider (easier to snap).

### Performance: Snap Detection on Every ACTION_MOVE

Snap detection runs on every `ACTION_MOVE` during drawing. With many elements on canvas, this could be expensive. Optimizations:
- **Spatial index:** Use a simple grid-based spatial hash of element bounding boxes. Only check elements near the candidate point.
- **Lazy computation:** Only compute expensive checks (intersection, perpendicular) if cheaper checks (endpoint, grid) fail.
- **Cache endpoints:** Cache `getEndpoints()` and `getMidpoints()` results per element — they don't change between moves.
- **Budget:** Snap detection should complete within 2ms to maintain 60fps draw loop.

### Coordinate Space Consistency

ALL snap math happens in **image-space**:
- `candidatePoint` is already in image-space (converted from touch via `screenToImage()`)
- Element endpoints/midpoints are stored in image-space
- Grid spacing is in image-space units
- Snap result returns image-space point

The HUD rendering (crosshairs, labels) converts back to screen-space for display using `imageToScreen()`.

### Integration with Drawing Flow

When a drawing tool is active and the user is dragging:
```
1. ACTION_MOVE → raw touch position (screen-space)
2. screenToImage(raw) → candidatePoint (image-space)
3. snapEngine.findSnap(candidatePoint, anchorPoint, elements, zoom)
4. If snap: use snappedPoint for live preview + final placement
5. If no snap: use candidatePoint
6. Render snap HUD at imageToScreen(snappedPoint)
```

## RESOLVED CONFLICTS

No spec conflicts for the snap engine — all specs agree on the behavior. The only clarification needed is from P-09 which resolves the priority order.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Curve-line intersection detection | Only line-line intersections for now | S13 (Freehand — adds curve geometry) |
| Snap settings popup (long-press toggle) | Toast "Snap settings coming later" | S18 (Properties) or later |
| Pressure-sensitive stroke width | Detect stylus pressure, log value, no visual effect yet | S09+ (drawing tools use pressure) |

## TEST CRITERIA

1. **Grid snap:** Draw a line with snap enabled → endpoint snaps to grid. Disable snap → no snap. Visual: crosshair + "# Grid" label at snap point.
2. **Angle snap:** Draw a line from point A → drag at ~43° → snaps to 45°. Line preview locks to 45° angle. Label shows "∠ 45°".
3. **Endpoint snap:** Place two test elements. Start new line near first element's endpoint → snaps to it. Crosshair shows "● End". Haptic fires.
4. **Midpoint snap:** Draw a line. Start new line near its midpoint → snaps. Label shows "◆ Mid".
5. **Priority order:** When an endpoint and grid point are both within threshold, endpoint wins (higher priority).
6. **Haptic on engage:** Moving from no-snap to snap → `CLOCK_TICK` fires. Staying on snap → no repeat haptic.
7. **Haptic on release:** Complete draw at snapped position → `CONFIRM` fires.
8. **Snap toggle:** Tap "Snap 45°" in top bar → text changes to "Snap OFF". Tap again → "Snap 45°". Drawing behavior changes accordingly.
9. **Grid overlay:** Toggle grid → light lines appear at grid intervals. Grid adjusts on zoom (lines don't become too dense or too sparse).
10. **Magnifier (finger):** Draw with finger, hold >150ms → magnifier loupe appears 60dp above touch. Shows 2.5× zoom. Disappears on finger-up.
11. **Stylus hover:** Hover stylus over canvas → light crosshair follows hover position. Touch down → hover crosshair disappears, draw begins.
12. **Zoom threshold scaling:** Zoom in 5× → snap threshold is tighter (need to be closer to endpoint). Zoom out → threshold is wider.
13. **Performance:** With 20 elements on canvas, draw gesture is smooth (60fps). Snap detection doesn't cause jank.
14. **Snap crosshair rendering:** Crosshair is 12dp arms, 1.5dp stroke, cyan. Not affected by canvas zoom (screen-space rendering).
15. **Rotate device:** Snap state survives rotation. Grid visibility preserved.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `SnapEngine.kt` | Core snap detection logic (pure Kotlin) |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `SnapResult.kt` | Snap result data class + SnapType enum |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `InputMode.kt` | Input mode enum + config |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `SnapHudRenderer.kt` | Crosshair, label, and reference highlight rendering |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `GridRenderer.kt` | Grid overlay rendering with zoom-adaptive spacing |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `MagnifierLoupe.kt` | Finger magnifier rendering |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `SpatialIndex.kt` | Simple grid-based spatial hash for element lookup |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:core:drawing` | `DrawableElement.kt` | Add `getEndpoints()`, `getMidpoints()`, `getLineSegments()` default methods to interface |
| `:feature:canvas` | `EditableTouchImageView.kt` | Integrate SnapEngine into draw gesture flow. Render snap HUD, grid, magnifier in `onDraw()`. Detect input mode (finger/stylus). Integrate stylus hover. |
| `:feature:canvas` | `CanvasViewModel.kt` | Add `snapEnabled`, `snapResult`, `showGrid`, `inputMode` state flows. Add `toggleSnap()` function. |
| `:feature:canvas` | `AnnotateTopBar` (in CanvasScreen or separate file from S05) | Wire snap toggle tap to `toggleSnap()`. Update display text from `snapEnabled` state. |

### Unit Tests

| Module | Test File | What It Tests |
|--------|-----------|--------------|
| `:core:drawing` | `SnapEngineTest.kt` | Grid snap at exact position, off-by-one, threshold boundary. Angle snap at 44°→45°, 46°→45°. Priority: endpoint over grid. No snap when disabled. |
| `:core:drawing` | `SpatialIndexTest.kt` | Insert 100 elements, query returns only nearby elements. Empty query returns empty. |

---

*Session 08 Blueprint — v1.0*
