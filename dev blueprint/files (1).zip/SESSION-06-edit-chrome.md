# Session 06 — Edit Mode Chrome

## GOAL

Implement the Edit Mode UI shell: top bar with ✕ Cancel / context info / ✓ Done, the 2dp cyan accent bar, the 6-slot edit toolbar (Flip, Rotate, Crop, Adjust, Overlay, More), active photo selection with cyan border highlighting, photo reorder by drag, cancel confirmation dialog, and undo stack snapshot on entry. This session makes Edit Mode fully navigable — individual tool behaviors (flip/rotate/crop/adjust/overlay) are implemented in later sessions.

## DEPENDS ON

- **S01 (Mode System)** — `AppMode.EDIT`, `enterEditMode(photoIndex)`, `exitEditMode()`, accent bar shell, top bar shell
- **S02 (Undo/Redo)** — `UndoManager` with edit stack, `UndoPill` composable
- **S03 (Drawing Surface)** — `EditableTouchImageView`, `viewMatrix`, coordinate system
- **S04 (Browse Chrome)** — FAB visibility rules (FABs hidden in Edit), import popup (hidden in Edit)

## SPEC REFERENCES

Read before coding:
- `INTERACTION-SPEC.md` §12 (Edit Mode — Photo & Overlay Interaction)
- `INTERACTION-SPEC.md` §15 (Top Bar — Edit Mode)
- `INTERACTION-SPEC.md` §20 (Complete Button Map — Edit column)
- Resolution R-01 (Edit Mode Toolbar — INTERACTION-SPEC 6-slot layout wins)
- Resolution R-03 (Single Photo Edit Entry — ✎ icon already in S04)
- Resolution R-04 (⚙ and 🔲 in Edit Mode when overlay selected)
- Resolution R-08 (Edit Mode Cancel + Undo Stack snapshot)
- Resolution R-12 (Pan Tool Visibility — disabled if not grid)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `CanvasScreen.kt` | `:feature:canvas` | Main composable — has mode-dependent top bar shell from S01, Browse chrome from S04, Annotate chrome from S05 | Add Edit-specific chrome here |
| `CanvasViewModel.kt` | `:feature:canvas` | State management — has `currentMode`, `activeTool`, `isDrawing`, browse/annotate state | Add edit photo index, edit toolbar state, cancel confirmation, undo snapshot |
| `UndoManager.kt` | `:core:undo` | Three independent stacks from S02 | Add `snapshotEditStack()` and `revertToSnapshot()` for cancel behavior |
| `UndoPill.kt` | `:feature:canvas` | Floating undo/redo pill from S02 | Already visible in Edit mode — no changes needed |
| `EditableTouchImageView.kt` | `:feature:canvas` | Touch handling, zoom/pan, mode awareness from S03 | Add active photo highlight (cyan border), dimmed inactive photos |

## DELIVERABLES

### Edit Mode Top Bar

1. **Full Edit top bar layout:**
   ```
   ┌────────────────────────────────────────────────────────────┐
   │  ✕ Cancel              Edit: Photo 1               ✓ Done │
   └────────────────────────────────────────────────────────────┘
   ```
   - **✕ Cancel** (left) — shows confirmation dialog if any edits were made (per R-08), then reverts undo stack to entry snapshot and exits to Browse
   - **Context info** (center) — "Edit: Photo N" where N is 1-indexed active photo. For single photo: "Edit: Photo". Updates when switching active photo in collage.
   - **✓ Done** (right) — commits all edits (undo stack stays as-is), exits to Browse

2. **Conditional overlay icons** (per R-04):
   - When an overlay is selected in Edit mode → add 🔲 Layers and ⚙ Properties icons before ✓ Done
   - Both are stubs showing toast for now (real implementation in S19/S18)
   - When no overlay selected → icons hidden

3. **2dp cyan accent bar** — `#00BCD4`, full width, below status bar, above top bar content. Already has accent bar infrastructure from S01 — set Edit mode color.

### Edit Mode Toolbar (6 Slots)

4. **Edit toolbar layout** (per R-01 — INTERACTION-SPEC definition wins):
   ```
   ┌──────────────────────────────────────────────────────────────┐
   │  ↔ Flip  │  ↻ Rotate  │  ⬒ Crop  │  ◐ Adjust  │  🖼 Overlay  │  ⋯ More │
   └──────────────────────────────────────────────────────────────┘
   ```
   - Pill-shaped container, 56dp height, 8dp from bottom edge, centered horizontally
   - Background: `Surface` color, rounded corners (28dp radius), subtle elevation
   - Each slot: icon + 10sp label below
   - Active tool: filled accent background at 15% opacity
   - All tools show toast "Coming in next session" when tapped — actual behaviors in S20 (Flip/Rotate/Crop), S21 (Adjust), S22 (Overlay)

5. **"More" overflow menu** in Edit Mode:
   ```
   ┌─────────────────────┐
   │  Add Photo          │  → stub: navigate to picker in "add" mode
   ├─────────────────────┤
   │  Remove Photo       │  → confirmation dialog, then remove (R-07)
   ├─────────────────────┤
   │  Edit Whole Image   │  → navigate to existing WholeImageEditScreen
   ├─────────────────────┤
   │  Pan                │  → enabled only for grid layouts (R-12)
   └─────────────────────┘
   ```
   - Pan: dynamically DISABLED (grayed out + tooltip "Grid layouts only") when layout is single photo or non-grid. Enabled only for grid/collage layouts per R-12.
   - Add Photo: opens picker in "add to collage" mode. On return, new photo appended to collage.
   - Remove Photo: shows confirmation dialog → on confirm, removes active photo. If reduces to 1 photo → collage-to-single fallback (R-13). If reduces to 0 → empty canvas (R-09).
   - Edit Whole Image: navigates to existing `WholeImageEditScreen` for full-canvas editing.

### Active Photo Selection

6. **Active photo highlighting:**
   - Active photo: 2dp cyan border (`#00BCD4`)
   - Inactive photos in collage: 1dp white border, dimmed to 60% opacity
   - Tap another photo in collage → switch active selection (update `activePhotoIndex`)
   - Single photo: always active (no border needed, but cyan accent bar indicates Edit mode)

7. **Photo reorder by drag (collage only):**
   - Long-press (300ms) on photo → lift animation (scale to 1.05×, elevation shadow)
   - Drag to another cell → swap positions
   - Horizontal layouts: 1D horizontal drag with cell-center crossing detection
   - Grid layouts: 2D drag with cell-index-based slot swapping
   - Haptic `CLOCK_TICK` on each swap
   - Release → settle animation (150ms)
   - Reorder pushes to edit undo stack

### Cancel Confirmation & Undo Snapshot (R-08)

8. **Undo stack snapshot on Edit Mode entry:**
   - When entering Edit Mode (from Browse via long-press or ✎ icon), capture a snapshot of the current edit undo stack state
   - Stored as `editStackSnapshot` in `UndoManager`

9. **Cancel confirmation dialog:**
   ```
   "Discard all changes?"
   [Keep Editing]  [Discard]
   ```
   - Shown when tapping ✕ Cancel AND the edit stack has entries beyond the snapshot
   - If no edits made since entry → exit immediately without dialog
   - On "Discard": revert edit undo stack to snapshot, exit to Browse
   - On "Keep Editing": dismiss dialog, stay in Edit mode

10. **✓ Done behavior:**
    - Commits all edits (undo stack preserved as-is)
    - Redo stack for edit mode is cleared
    - Exits to Browse mode

## DATA MODELS

```kotlin
// In CanvasViewModel — new state fields for Edit Mode
val activePhotoIndex: StateFlow<Int>             // 0-indexed, which photo is being edited
val editToolbarState: StateFlow<EditTool>         // which edit tool is active
val showEditMoreMenu: StateFlow<Boolean>          // overflow menu visibility
val showCancelConfirmation: StateFlow<Boolean>    // cancel dialog visibility
val hasUnsavedEdits: StateFlow<Boolean>           // true if edit stack differs from snapshot

// New sealed class for Edit Mode tools
sealed class EditTool {
    object None : EditTool()
    object Flip : EditTool()
    object Rotate : EditTool()
    object Crop : EditTool()
    object Adjust : EditTool()
    object Overlay : EditTool()
}
```

```kotlin
// In UndoManager — snapshot support
fun snapshotEditStack(): EditStackSnapshot     // capture current edit state
fun revertToSnapshot(snapshot: EditStackSnapshot) // restore to captured state
fun hasEditsAfterSnapshot(snapshot: EditStackSnapshot): Boolean

data class EditStackSnapshot(
    val undoSize: Int,
    val stackHash: Int   // simple hash to detect changes
)
```

## KEY IMPLEMENTATION DETAILS

### Toolbar vs Annotate Mode Toolbar

The Edit toolbar is structurally similar to the Annotate toolbar (pill-shaped, bottom, 56dp) but:
- Has **different content** (6 edit tools vs 6 annotation categories)
- Has **no category tray** — each tool is a direct action or opens its own sub-UI
- The toolbar **stays visible** during all edit operations (no auto-hide — auto-hide is Annotate-only)
- Active tool gets filled accent tint (same visual treatment as Annotate)

### Edit Mode Entry/Exit Flow

```
BROWSE → EDIT:
  1. User long-presses photo OR taps ✎ icon
  2. enterEditMode(photoIndex) called
  3. UndoManager.snapshotEditStack()
  4. Mode transitions to EDIT
  5. FABs fade out (200ms), Browse chrome replaced by Edit chrome
  6. Active photo gets cyan border, others dim
  7. Edit toolbar slides up (200ms)

EDIT → BROWSE (Done):
  1. User taps ✓ Done
  2. Edit undo stack preserved (edits committed)
  3. Redo stack cleared
  4. Mode transitions to BROWSE
  5. Edit chrome replaced by Browse chrome
  6. FABs fade in (200ms)

EDIT → BROWSE (Cancel):
  1. User taps ✕ Cancel
  2. If hasUnsavedEdits → show confirmation dialog
  3. On Discard → UndoManager.revertToSnapshot()
  4. Mode transitions to BROWSE
  5. Edit chrome replaced by Browse chrome
  6. FABs fade in (200ms)
```

### "Add Photo" from Edit Mode (F-27 resolution)

After adding a photo from Edit Mode's "More → Add Photo":
- Photo is added to the collage
- User returns to **Edit Mode** (not Browse) with the newly added photo as active
- This is a Browse-level layout change, so it also pushes to the browse undo stack

## RESOLVED CONFLICTS

**R-01:** Edit Mode toolbar uses the INTERACTION-SPEC 6-slot layout: Flip, Rotate, Crop, Adjust (inline), Overlay, More. NOT the APP-FEATURES 8-button layout.

**R-04:** ⚙ Properties and 🔲 Layers icons appear in Edit Mode top bar ONLY when an overlay is selected. Otherwise hidden. Both are stubs in this session.

**R-08:** Cancel shows confirmation dialog only if edits were made. Discard reverts to undo snapshot.

**R-12:** Pan in "More" overflow is disabled (grayed + tooltip) when layout is single photo. Enabled for grid/collage layouts only.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Flip tool behavior | Show toast, set `editToolbarState = Flip` | S20 (future — not in SESSION-MASTER-PLAN as separate; part of Edit tools) |
| Rotate tool behavior | Show toast | S20 |
| Crop tool behavior | Show toast | S20 |
| Adjust inline sliders | Show toast | S21 |
| Overlay placement | Show toast | S22 |
| ⚙ Properties (overlay) | Show toast | S18 (Properties Sheet) |
| 🔲 Layers (overlay) | Show toast | S19 (Layer Panel) |
| Pan tool | Show toast "Grid layouts only" when single | Future |

## TEST CRITERIA

1. **Edit mode entry (long-press):** Long-press photo in Browse → enters Edit mode. Cyan accent bar visible. Edit toolbar visible. FABs hidden.
2. **Edit mode entry (✎ icon):** Single photo → tap ✎ in top bar → enters Edit mode.
3. **Top bar layout:** ✕ Cancel (left), "Edit: Photo 1" (center), ✓ Done (right) all visible.
4. **Edit toolbar visible:** 6 slots with correct icons and labels. Pill-shaped at bottom.
5. **Active photo cyan border:** In collage, active photo has cyan border, others dimmed.
6. **Switch active photo:** Tap another photo in collage → context changes to "Edit: Photo N", cyan border moves.
7. **Reorder by drag:** Long-press + drag photo in collage → swaps with target. Haptic on swap. Undo stack receives entry.
8. **"More" overflow menu:** Tap ⋯ → 4 items shown. Pan grayed out for single photo.
9. **Cancel with no edits:** Tap ✕ Cancel with no edits → exits immediately to Browse.
10. **Cancel with edits:** Make an edit (e.g., via future tool), tap ✕ Cancel → confirmation dialog appears. "Discard" exits. "Keep Editing" stays.
11. **Done commits:** Tap ✓ Done → exits to Browse. Edits preserved.
12. **Undo pill visible:** Floating pill visible on left edge in Edit mode.
13. **Remove photo (collage):** More → Remove Photo → confirmation → photo removed. If 1 remains → single photo fallback (R-13).
14. **Remove photo (single):** More → Remove Photo → confirmation → empty canvas (R-09).
15. **Edit Whole Image:** More → Edit Whole Image → navigates to `WholeImageEditScreen`. On return → back in Edit mode.
16. **Back gesture:** System back gesture → same as ✕ Cancel (confirmation if needed).
17. **Rotate device:** Edit mode chrome survives rotation. Active photo index preserved.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `EditTopBar.kt` | Full Edit mode top bar composable |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `EditToolbar.kt` | 6-slot edit tools pill bar |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `EditMoreMenu.kt` | Overflow popup (Add Photo, Remove, Edit Whole, Pan) |
| `:core:undo` | `com.bcd.technotes.core.undo` | `EditStackSnapshot.kt` | Snapshot data class for cancel/revert |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:feature:canvas` | `CanvasViewModel.kt` | Add `activePhotoIndex`, `editToolbarState`, `showEditMoreMenu`, `showCancelConfirmation`, `hasUnsavedEdits`. Add `enterEditMode(index)` with snapshot, `exitEditDone()`, `exitEditCancel()`, `switchActivePhoto(index)`, `removePhoto()`. |
| `:feature:canvas` | `CanvasScreen.kt` | Add Edit mode chrome branch: `EditTopBar`, `EditToolbar`, `EditMoreMenu`. Add cancel confirmation dialog. |
| `:core:undo` | `UndoManager.kt` | Add `snapshotEditStack()`, `revertToSnapshot()`, `hasEditsAfterSnapshot()` |
| `:feature:canvas` | `EditableTouchImageView.kt` | Add active photo border rendering (cyan 2dp for active, white 1dp + dim for inactive). Handle tap-to-switch in Edit mode. |

---

*Session 06 Blueprint — v1.0*
