# Session 12 — Text Tool

## GOAL

Implement the complete text annotation system: direct-action activation from toolbar slot 4 (no tray), tap-canvas-to-place with immediate keyboard, multi-line support, live canvas preview during typing, bounding box auto-sizing, double-tap to re-edit, drag to reposition, pinch to resize font, and the `TextAnnotationElement` drawable. This is the most frequently used annotation tool (~30% of actions) and must feel instant.

## DEPENDS ON

- **S07 (Tool Palette)** — `ToolPalette`, `ActiveTool.Text`, Text slot as direct-action (tap activates instantly, no tray)
- **S03 (Drawing Surface)** — `EditableTouchImageView`, `DrawableElement` interface, `GestureRouter`, `screenToImage()`, rendering pipeline, `isDrawing` state for chrome auto-hide
- **S09 (Lines + Selection)** — `SelectionHandler` (tap-to-select, move, delete), `CanvasViewModel` element CRUD, context bar wiring
- **S05 (Annotate Chrome)** — Chrome auto-hide during draw (keyboard visibility = exception that keeps chrome visible)
- **S02 (Undo/Redo)** — `UndoManager` annotate stack

## SPEC REFERENCES

Read before coding:
- `INTERACTION-SPEC.md` §6 (Text Tool — activation flow, editing, properties, data model)
- `GRAPHIC-ELEMENT-EDITING-SPEC.md` §3 (Text Properties — font size, alignment, bold/italic, background fill, rotation, line height, max width, overflow, convert-to-leader)
- `FINAL-complete-implementation-spec.md` §2 (Text Rule — computed vs manual distinction)
- `INTERACTION-SPEC.md` §5 (Bottom Tool Palette — Text is slot 4, direct action)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-05 (Progressive Disclosure)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `GestureRouter.kt` | `:core:drawing` | Routes by mode+tool from S03 | `ActiveTool.Text` → route taps to text placement handler |
| `SelectionHandler.kt` | `:core:drawing` | Universal select/move/delete from S09 | Reuse for text selection + add pinch-to-resize |
| `CanvasViewModel.kt` | `:feature:canvas` | Element CRUD, active tool state | Add text-specific state: `isTextInputActive`, `editingTextElement` |
| `EditableTouchImageView.kt` | `:feature:canvas` | Touch handling + rendering | Route Text tool taps. Render text elements. Support double-tap detection for re-edit. |
| `ChromeAutoHideController` | `:feature:canvas` | Auto-hide from S05 | `isKeyboardVisible` + `isTextInputActive` flags prevent chrome hide during text entry |
| `ToolRegistry.kt` | `:core:model` | Tool definitions from S07 | Text tool = direct action, toolId for text |
| `DrawableElement.kt` | `:core:drawing` | Interface from S03 | Implement for `TextAnnotationElement` |

## DELIVERABLES

### Text Tool Activation

1. **Direct-action pattern:**
   - Tap "T" in toolbar → `ActiveTool.Text` immediately (no tray animation)
   - Top bar center text changes to "Text"
   - Canvas enters text placement mode: next tap on canvas places text cursor

### Text Placement Flow

2. **`TextPlacementHandler` class** in `:core:drawing`:
   ```
   STATE MACHINE:
   IDLE → (ActiveTool.Text set) → AWAITING_TAP
   AWAITING_TAP → (tap on empty canvas) → EDITING
     Create temporary TextAnnotationElement at tap point.
     Open keyboard IMMEDIATELY (no delay).
     Set isTextInputActive = true (chrome auto-hide exception).
   EDITING → (user types) → EDITING
     Live update text on canvas. Bounding box auto-resizes.
   EDITING → (tap ✓ / keyboard Done) → COMMITTED
     If text not empty: finalize element, push to undo stack.
     If text empty: discard element.
     isTextInputActive = false.
     Tool remains active (AWAITING_TAP) for next placement.
   EDITING → (tap elsewhere on canvas) → COMMITTED + NEW_EDIT
     Commit current text. Start new text at new tap point.
   AWAITING_TAP → (tap on existing TextAnnotationElement) → RE_EDITING
     Select the element. Open keyboard with existing text. Cursor at tap position.
   AWAITING_TAP → (tool change or ✕ Done) → IDLE
   ```

3. **Keyboard opens IMMEDIATELY** — use `SoftwareKeyboardController` or `FocusRequester` in Compose. The 0ms delay is critical for the "pen-to-paper" feel. Do NOT use postDelayed or other artificial delays.

### TextAnnotationElement

4. **`TextAnnotationElement` class** implementing `DrawableElement`:
   ```kotlin
   data class TextAnnotationData(
       val position: PointF,          // image-space (top-left of bounding box)
       val text: String,              // multi-line with \n
       val fontSize: Float,           // in IMAGE-SPACE PIXELS (not sp)
       val color: Int,
       val alignment: TextAlignment,  // LEFT, CENTER, RIGHT
       val isBold: Boolean = false,
       val isItalic: Boolean = false,
       val backgroundFill: Boolean = false,
       val rotation: Float = 0f,      // degrees
       val layer: String,
       val opacity: Float = 1.0f,
       val isLocked: Boolean = false
   )

   enum class TextAlignment { LEFT, CENTER, RIGHT }
   ```

5. **Rendering on Canvas:**
   - Use `StaticLayout` (Android text layout engine) for multi-line text with alignment
   - `Paint.textSize` = `fontSize` (image-space pixels — viewMatrix handles display scaling)
   - Font: Plus Jakarta Sans (from `:core:ui` resources)
   - Bold/italic via `Paint.setTypeface(Typeface.create(baseFont, style))`
   - Anti-aliasing always on
   - Background fill: semi-transparent rect (#000000 at 30% opacity) behind text, 4dp padding

6. **Bounding box:**
   - Computed from `StaticLayout` width and height
   - Auto-sizes as text changes (no fixed width by default)
   - Position is top-left corner of bounding box in image-space
   - For CENTER alignment: text centered within the computed width
   - Bounding box visible during editing (thin dashed cyan border)

### Live Preview During Typing

7. **Real-time canvas update:**
   - `CanvasViewModel.activeDrawing` holds the in-progress `TextAnnotationElement`
   - Every keystroke updates the element's text → triggers canvas redraw
   - `StaticLayout` recomputed on each text change (fast for typical annotation text lengths)
   - Bounding box smoothly resizes with content

### Text Editing Overlay

8. **`TextEditOverlay` composable** in `:feature:canvas`:
   - Positioned at the text element's screen-space location (apply viewMatrix)
   - Contains a transparent `TextField` that captures keyboard input
   - Text renders on canvas (NOT in the TextField) — the TextField is invisible, only for input capture
   - Engineering symbols bar above keyboard: 32dp height, horizontally scrollable
   - Placeholder symbols for now: `Ø R SR ± ° × ⌀` (full set in S26)
   - Tap symbol → insert at cursor position

### Editing Existing Text

9. **Double-tap to re-edit:**
   - Double-tap (2 taps <300ms, <15dp apart) on a placed `TextAnnotationElement`
   - Keyboard reopens with existing text loaded
   - Cursor placed at tap position within text (map screen tap to character offset)
   - Edit/delete/append text
   - Tap ✓ → commit changes (push edit action to undo: stores before+after text)

### Gesture Integration

10. **Drag to reposition:**
    - One-finger drag on selected text element → move (handled by existing `SelectionHandler`)
    - Snap to grid/alignment points via SnapEngine (S08)

11. **Pinch to resize:**
    - Two-finger pinch on selected text element → scale fontSize proportionally
    - Minimum: 6px image-space. Maximum: 200px image-space.
    - Pinch release → push resize to undo stack
    - Note: two-finger pinch on TEXT conflicts with canvas zoom. Resolution:
      - If both fingers START inside the text bounding box → resize text
      - If either finger starts outside → canvas zoom (normal behavior)

12. **Two-finger rotation:**
    - Two-finger twist on selected text → rotate
    - Snaps at 0°, 45°, 90°, 135°, 180° with haptic detent
    - Same inside-bounding-box rule as pinch

### Font Size in Image-Space

13. **Critical: fontSize is in image-space pixels, NOT sp/dp.**
    - A text with fontSize=50 appears as 50px in the image
    - When zoomed 2×, it appears as 100 screen pixels (viewMatrix scales it)
    - When zoomed 0.5×, it appears as 25 screen pixels
    - This ensures text scales with the photo, not with display density
    - Default fontSize on placement: 16dp converted to image-space (`16 * density / currentZoom`)

## DATA MODELS

```kotlin
// In :core:model — TextAnnotation.kt
data class TextAnnotationData(
    val position: PointF,
    val text: String,
    val fontSize: Float,          // image-space pixels
    val color: Int,
    val alignment: TextAlignment,
    val isBold: Boolean = false,
    val isItalic: Boolean = false,
    val backgroundFill: Boolean = false,
    val rotation: Float = 0f,
    val layer: String,
    val opacity: Float = 1.0f,
    val isLocked: Boolean = false
)

enum class TextAlignment { LEFT, CENTER, RIGHT }
```

```kotlin
// In :feature:canvas — CanvasViewModel additions
val isTextInputActive: StateFlow<Boolean>     // true during text editing
val editingTextElement: StateFlow<String?>    // ID of element being edited (null = new)
```

## KEY IMPLEMENTATION DETAILS

### StaticLayout for Multi-Line Text Rendering

```kotlin
fun TextAnnotationElement.draw(canvas: Canvas, zoom: Float) {
    val paint = TextPaint(Paint.ANTI_ALIAS_FLAG).apply {
        textSize = data.fontSize
        color = data.color
        typeface = getTypeface(data.isBold, data.isItalic)
        alpha = (data.opacity * 255).toInt()
    }

    val maxWidth = if (data.text.contains('\n')) {
        // Multi-line: compute max line width
        data.text.lines().maxOf { paint.measureText(it) }.toInt() + 1
    } else {
        // Single line: no width constraint
        (paint.measureText(data.text) + 1).toInt()
    }

    val layout = StaticLayout.Builder.obtain(data.text, 0, data.text.length, paint, maxWidth)
        .setAlignment(when (data.alignment) {
            TextAlignment.LEFT -> Layout.Alignment.ALIGN_NORMAL
            TextAlignment.CENTER -> Layout.Alignment.ALIGN_CENTER
            TextAlignment.RIGHT -> Layout.Alignment.ALIGN_OPPOSITE
        })
        .setLineSpacing(0f, 1.2f)  // 1.2× line height
        .build()

    canvas.save()
    if (data.rotation != 0f) {
        canvas.rotate(data.rotation, data.position.x + layout.width / 2f, data.position.y + layout.height / 2f)
    }

    // Background fill
    if (data.backgroundFill) {
        val bgPaint = Paint().apply {
            color = Color.argb(77, 0, 0, 0) // 30% black
            style = Paint.Style.FILL
        }
        val padding = 4f * (1f / zoom).coerceAtLeast(1f)
        canvas.drawRect(
            data.position.x - padding, data.position.y - padding,
            data.position.x + layout.width + padding,
            data.position.y + layout.height + padding,
            bgPaint
        )
    }

    canvas.translate(data.position.x, data.position.y)
    layout.draw(canvas)
    canvas.restore()
}
```

### Hit-Testing Text

```kotlin
fun TextAnnotationElement.hitTest(point: PointF, hitRadius: Float): Boolean {
    // Compute bounding rect from StaticLayout
    val bounds = getBoundingRect()
    // Expand by hitRadius
    val expanded = RectF(bounds).apply { inset(-hitRadius, -hitRadius) }
    // If rotated, inverse-rotate the test point around center
    if (data.rotation != 0f) {
        val center = PointF(bounds.centerX(), bounds.centerY())
        val rotated = rotatePoint(point, center, -data.rotation)
        return expanded.contains(rotated.x, rotated.y)
    }
    return expanded.contains(point.x, point.y)
}
```

### Cursor Position Mapping for Re-Edit

When double-tapping existing text, map the tap's image-space position to a character offset:
```kotlin
fun mapTapToOffset(tapPoint: PointF, layout: StaticLayout, textPosition: PointF): Int {
    val localX = tapPoint.x - textPosition.x
    val localY = tapPoint.y - textPosition.y
    val line = layout.getLineForVertical(localY.toInt()).coerceIn(0, layout.lineCount - 1)
    return layout.getOffsetForHorizontal(line, localX)
}
```

### Chrome Auto-Hide Integration

- When text editing starts: set `ChromeAutoHideController.isTextInputActive = true`
- This prevents toolbar and top bar from hiding during text input
- When keyboard is visible: `ChromeAutoHideController.isKeyboardVisible = true`
- Both flags keep chrome visible
- On commit/cancel: clear both flags → chrome returns to normal auto-hide behavior

## RESOLVED CONFLICTS

- **Text fontSize units:** INTERACTION-SPEC says "8sp–72sp" for the slider range, but the data model stores image-space pixels. Resolution: the slider in S18 shows sp-equivalent labels but stores as image-space pixels. For this session, fontSize is always image-space.
- **Pinch-to-resize vs canvas zoom:** Two-finger gestures on text could conflict with canvas zoom. Resolution: if both fingers start inside the text bounding box, resize text; otherwise, zoom canvas. This is consistent with the overlay two-finger exception from R-06.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Engineering symbols bar | Scrollable bar with 8 placeholder symbols (Ø R SR ± ° × ⌀ □). Tap inserts at cursor. | S26 (Engineering Keyboard) |
| Text properties sheet | Font size, alignment, bold/italic, background fill, rotation all stored but no UI to change post-placement (except double-tap re-edit for text content) | S18 (Properties Sheet) |
| "Convert to Leader" | Button exists in concept but no UI. Leader+Text (#40) not yet implemented. | S15 (Leader+Text) |
| Context bar ⚙ for text | Shows toast | S18 (Properties Sheet) |
| Keyboard modes (NUMERIC, ALPHA-CODE, FREE-TEXT) | Only FREE-TEXT mode implemented. Mode switching deferred. | S26 (Engineering Keyboard) |
| Auto-increment | No auto-increment suggestions yet | S26 (Engineering Keyboard) |

## TEST CRITERIA

1. **Activate text tool:** Tap "T" → tool activates instantly (no tray). Top bar shows "Text".
2. **Place text:** Tap canvas → keyboard opens immediately → type "Hello World" → text appears on canvas live.
3. **Commit text:** Tap ✓ (Done) → text finalized. Keyboard dismisses. Tool stays active.
4. **Place second text:** After committing, tap elsewhere → new text placement. Both texts visible.
5. **Empty text discard:** Tap canvas → keyboard opens → tap ✓ without typing → no element created.
6. **Multi-line:** Type "Line 1" → Enter → "Line 2" → ✓. Two lines rendered on canvas.
7. **Bounding box auto-size:** Type short text → small box. Type long text → box widens. Delete text → box shrinks.
8. **Double-tap re-edit:** Double-tap a placed text → keyboard opens with existing text. Edit → ✓ → updated.
9. **Drag to move:** Select text element → one-finger drag → text moves. Undo → returns to original position.
10. **Pinch to resize:** Two fingers inside text bounding box → pinch → fontSize changes proportionally. 
11. **Pinch outside = zoom:** Two fingers where at least one is outside text box → canvas zooms normally.
12. **Background fill:** Place text with backgroundFill=true → semi-transparent rect behind text.
13. **Alignment:** Place three texts with LEFT, CENTER, RIGHT → each aligned correctly.
14. **Bold/Italic:** Place text with bold=true → renders bold. Italic=true → renders italic.
15. **Font size in image-space:** Zoom 2× → text appears 2× larger on screen (scales with photo). Zoom 0.5× → appears smaller.
16. **Symbols bar:** Engineering symbols bar visible above keyboard. Tap "Ø" → "Ø" inserted at cursor.
17. **Undo text add:** Place text → undo → text removed. Redo → text restored.
18. **Undo text edit:** Edit text "A" to "B" → undo → text shows "A" again.
19. **Selection:** With Select tool, tap text → selected (context bar shows). 
20. **Delete:** Select text → 🗑 → deleted. Undo → restored.
21. **Chrome behavior:** During text editing, toolbar and top bar remain visible (not auto-hidden).
22. **Rotation:** Rotate device during text editing → keyboard stays open, text position correct.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `TextAnnotationElement.kt` | Text drawable with StaticLayout rendering, hit-test, bounding box |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `TextPlacementHandler.kt` | Gesture state machine for text placement + editing |
| `:core:model` | `com.bcd.technotes.core.model` | `TextAnnotationData.kt` | Data class + TextAlignment enum |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `TextEditOverlay.kt` | Composable with invisible TextField + symbols bar |
| `:feature:canvas` | `com.bcd.technotes.feature.canvas.ui` | `EngineeringSymbolsBar.kt` | 32dp scrollable symbols bar (placeholder set) |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:core:drawing` | `GestureRouter.kt` | `ActiveTool.Text` → route taps to `TextPlacementHandler`. Double-tap detection for re-edit. |
| `:core:drawing` | `SelectionHandler.kt` | Add pinch-to-resize for text elements (inside bounding box check). |
| `:core:drawing` | `ElementFactory.kt` | Add text tool creation (though text is special — created by handler, not factory) |
| `:feature:canvas` | `CanvasViewModel.kt` | Add `isTextInputActive`, `editingTextElement`, `commitText()`, `cancelText()`, `updateTextInProgress()` |
| `:feature:canvas` | `EditableTouchImageView.kt` | Render `TextAnnotationElement` in draw pipeline. Support double-tap detection → re-edit. |
| `:feature:canvas` | `CanvasScreen.kt` | Overlay `TextEditOverlay` when text input active. Manage keyboard lifecycle. |
| `:feature:canvas` | `ChromeAutoHideController` (from S05) | Wire `isTextInputActive` and `isKeyboardVisible` flags |

### Unit Tests

| Module | Test File | What It Tests |
|--------|-----------|--------------|
| `:core:drawing` | `TextAnnotationElementTest.kt` | `hitTest()` with/without rotation, bounding box computation, StaticLayout doesn't crash with empty/long text |
| `:core:drawing` | `TextPlacementHandlerTest.kt` | State machine: AWAITING→EDITING→COMMITTED. Empty text discarded. Re-edit flow. |

---

*Session 12 Blueprint — v1.0*
