# Session 10 — Arrowhead Renderer (20 Styles)

## GOAL

Implement the complete `ArrowheadRenderer` object with all 20 arrowhead styles, the `ArrowStyle` enum (23 entries including NONE), core triangle vertex geometry using atan2, inset point calculation, a 5×4 visual picker grid, and integration with existing line elements from S09. Replace the placeholder `drawPlaceholderArrow()` with the real system.

## DEPENDS ON

- **S09 (Two-Point Lines + Selection)** — `StraightLineElement`, `GrainlineArrowElement`, `ArrowStyle` enum stub, `drawPlaceholderArrow()`, `TwoPointElement` base class, element selection and rendering pipeline
- **S03 (Drawing Surface)** — `EditableTouchImageView` rendering pipeline, viewMatrix, zoom-aware rendering
- **S02 (Undo/Redo)** — Property changes push to annotate undo stack

## SPEC REFERENCES

Read before coding:
- `FINAL-complete-implementation-spec.md` §3 (Arrowhead System — enum, geometry, proportions, full Kotlin renderer, line integration, dimension flip, pitfalls)
- `GRAPHIC-ELEMENT-EDITING-SPEC.md` §4.1 (Arrow Style picker, Arrow Size multiplier, Stroke Cap)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-05 (Progressive Disclosure)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `StraightLineElement.kt` | `:core:drawing` | Has `startArrow`, `endArrow` fields + placeholder render | Replace `drawPlaceholderArrow()` calls with `ArrowheadRenderer.draw()` |
| `GrainlineArrowElement.kt` | `:core:drawing` | Always double-headed | Both endpoints get arrowheads via `ArrowheadRenderer.draw()` |
| `TwoPointElement.kt` | `:core:drawing` | Abstract base for all lines | Add optional `arrowSizeMultiplier` field |
| `ElementFactory.kt` | `:core:drawing` | Creates elements from toolId | Pass arrow defaults from `ToolDefaults` |
| `EditableTouchImageView.kt` | `:feature:canvas` | Rendering pipeline | No changes — arrowheads render inside element's `draw()` |
| `AnnotationContextBar` | `:feature:canvas` | Context bar from S05/S09 | Stub ⚙ still shows toast (full picker in S18 Properties) |

## DELIVERABLES

### ArrowStyle Enum

1. **Complete `ArrowStyle` enum** in `:core:model` (replace placeholder from S09):
   ```kotlin
   enum class ArrowStyle {
       // Triangular (8)
       CLOSED_FILLED,      // ① solid triangle (ASME default)
       CLOSED_BLANK,       // ② outlined triangle (hollow)
       OPEN,               // ③ two wings, no base (ISO default)
       OPEN_30,            // ④ narrow 30° open
       OPEN_90,            // ⑤ wide 90° open
       CLOSED_HALF,        // ⑥ top half filled, bottom outlined
       DATUM_FILLED,       // ⑦ wide filled (equilateral-like)
       DATUM_BLANK,        // ⑧ wide outlined

       // Geometric shapes (7)
       DOT_FILLED,         // ⑨ filled circle
       DOT_SMALL,          // ⑩ smaller filled circle
       DOT_BLANK,          // ⑪ outlined circle (hollow)
       BOX_FILLED,         // ⑫ filled square, rotates with line
       BOX_BLANK,          // ⑬ outlined square
       DIAMOND_FILLED,     // ⑭ filled diamond (rotated square)
       DIAMOND_BLANK,      // ⑮ outlined diamond

       // Line-based (4)
       OBLIQUE,            // ⑯ 45° slash/tick (architectural)
       INTEGRAL,           // ⑰ perpendicular line across endpoint
       RIGHT_ANGLE,        // ⑱ L-shape (ordinate origin)
       CROSS,              // ⑲ + mark through endpoint

       // Special (4)
       ORIGIN_INDICATOR,   // ⑳ circle + short radius line
       DOUBLE_BARB,        // ㉑ two nested open arrow wings
       CONCAVE,            // ㉒ barbed/scooped base triangle
       NONE                // ㉓ no terminator
   }
   ```

### ArrowheadRenderer Object

2. **`ArrowheadRenderer` object** in `:core:drawing`:
   - Single `draw()` function: takes `(canvas, tip, angleRad, style, strokeWidth, color)` → returns `PointF` (inset point)
   - Routes to private render functions by style category
   - **INSET POINT is critical**: the parent line must stop at the returned inset point, NOT at the tip. This prevents line-pokes-through-arrowhead.

3. **Core geometry — triangle vertex computation:**
   ```
   angle = atan2(E.y - S.y, E.x - S.x)     // ALWAYS atan2, argument order is (Y, X)
   tip = endpoint
   baseCenter = tip - headLength * (cos(angle), sin(angle))
   left  = baseCenter + halfWidth * (sin(angle), -cos(angle))
   right = baseCenter - halfWidth * (sin(angle), -cos(angle))
   Draw: tip → left → right → close
   INSET POINT = baseCenter
   ```

4. **Proportions by category:**
   ```
   STANDARD (①②③):   headLength = max(strokeWidth * 3.0, 10dp)
                       halfWidth  = max(strokeWidth * 1.0, 3.5dp)

   NARROW (④):        halfWidth  = headLength * tan(15°) ≈ headLength * 0.27

   WIDE (⑤⑦⑧):       halfWidth  = headLength * 1.0 (equilateral-like)

   DIMENSION ARROWS:   headLength = 8dp (FIXED), halfWidth = 3dp (FIXED)

   DOT (⑨⑩⑪):        radius = max(strokeWidth * 1.5, 4dp)
                       DOT_SMALL: radius = max(strokeWidth * 0.8, 2.5dp)

   BOX (⑫⑬):         halfSide = max(strokeWidth * 1.2, 4dp)

   DIAMOND (⑭⑮):     forwardLen = max(strokeWidth * 2.0, 6dp)
                       sideLen = max(strokeWidth * 1.2, 4dp)

   SLASH (⑯):         slashLen = max(strokeWidth * 3.0, 8dp)

   INTEGRAL/CROSS (⑰⑲): armLen = max(strokeWidth * 2.0, 6dp)
   ```

5. **Private render functions (one per category):**
   - `drawTriangle(canvas, tip, angle, sw, paint, fill, ratio)` — handles ①②⑥⑦⑧
   - `drawOpenWings(canvas, tip, angle, sw, paint, ratio)` — handles ③④⑤
   - `drawHalfFilled(canvas, tip, angle, sw, paint)` — handles ⑥
   - `drawDot(canvas, tip, angle, sw, paint, fill, sizeMultiplier)` — handles ⑨⑩⑪
   - `drawBox(canvas, tip, angle, sw, paint, fill)` — handles ⑫⑬
   - `drawDiamond(canvas, tip, angle, sw, paint, fill)` — handles ⑭⑮
   - `drawSlash(canvas, tip, angle, sw, paint)` — handles ⑯
   - `drawIntegral(canvas, tip, angle, sw, paint)` — handles ⑰
   - `drawRightAngle(canvas, tip, angle, sw, paint)` — handles ⑱
   - `drawCross(canvas, tip, angle, sw, paint)` — handles ⑲
   - `drawOriginIndicator(canvas, tip, angle, sw, paint)` — handles ⑳
   - `drawDoubleBarb(canvas, tip, angle, sw, paint)` — handles ㉑
   - `drawConcave(canvas, tip, angle, sw, paint)` — handles ㉒

### Paint Rules

6. **Paint configuration:**
   - Filled triangles: `Paint.Style.FILL` + `Paint.Join.MITER` + `strokeMiter = 10f` for sharp tips
   - Outlined/blank shapes: `Paint.Style.STROKE` with white fill for hollow center
   - Open wings: `Paint.Style.STROKE` + `Paint.Cap.ROUND` (no fill, just two angled lines)
   - All: `Paint.ANTI_ALIAS_FLAG` always set

### Line Integration

7. **`drawLineWithArrows()` utility function:**
   ```kotlin
   fun drawLineWithArrows(
       canvas: Canvas, start: PointF, end: PointF,
       strokeWidth: Float, color: Int,
       startArrow: ArrowStyle, endArrow: ArrowStyle,
       dashPattern: FloatArray?
   ) {
       val angle = atan2(end.y - start.y, end.x - start.x)
       // 1. Draw arrowheads FIRST → get inset points
       var lineStart = start
       var lineEnd = end
       if (endArrow != ArrowStyle.NONE)
           lineEnd = ArrowheadRenderer.draw(canvas, end, angle, endArrow, strokeWidth, color)
       if (startArrow != ArrowStyle.NONE)
           lineStart = ArrowheadRenderer.draw(canvas, start, angle + PI.toFloat(), startArrow, strokeWidth, color)
       // 2. Draw line BETWEEN inset points
       canvas.drawLine(lineStart.x, lineStart.y, lineEnd.x, lineEnd.y, paint)
   }
   ```

### Arrow Size Multiplier

8. **`arrowSizeMultiplier` property** added to `TwoPointElement`:
   - Range: 0.5× – 2.5×, default 1.0×
   - Applied in ArrowheadRenderer: multiply `headLength` and `halfWidth` by multiplier
   - Stored per-element, settable from properties (S18)

### Dimension Arrow Flip

9. **Tight-space logic** for dimension lines (used in S17 but implemented now):
   ```kotlin
   fun drawDimensionArrows(canvas, leftTip, rightTip, style, color) {
       val distance = abs(rightTip.x - leftTip.x)
       val headLength = 8f // fixed for dimensions
       if (distance > headLength * 4) {
           // NORMAL: arrows point INWARD
           ArrowheadRenderer.draw(canvas, leftTip, 0f, style, 1.5f, color)
           ArrowheadRenderer.draw(canvas, rightTip, PI.toFloat(), style, 1.5f, color)
       } else {
           // TIGHT: arrows flip OUTWARD, text moves outside
           ArrowheadRenderer.draw(canvas, leftTip, PI.toFloat(), style, 1.5f, color)
           ArrowheadRenderer.draw(canvas, rightTip, 0f, style, 1.5f, color)
       }
   }
   ```

### Arrowhead Picker Grid (Stub)

10. **`ArrowheadPickerGrid` composable** in `:core:ui`:
    - 5×4 grid (rows: Triangular, Geometric, Line-based, Special; + NONE at end)
    - Each cell: 40dp rendered preview of the arrow style at 0° angle
    - Selected style: cyan ring border
    - Returns `ArrowStyle` on selection
    - For now: usable standalone. Wired into properties sheet in S18.

## DATA MODELS

```kotlin
// In :core:model — ArrowStyle.kt (replace stub from S09)
// Full enum as listed in Deliverable 1

// In :core:drawing — TwoPointElement.kt modifications
abstract class TwoPointElement(...) {
    // Add:
    abstract val arrowSizeMultiplier: Float  // default 1.0f
}
```

## KEY IMPLEMENTATION DETAILS

### Critical Pitfalls (from spec)

```
PITFALL 1: Line pokes through arrowhead
  FIX: Draw line from start to INSET point (returned by draw()), not to tip.

PITFALL 2: Arrow flips wrong at certain angles
  FIX: Always use atan2(dy, dx). Argument order is (Y, X). Never use atan(dy/dx).

PITFALL 3: Blurry/rounded arrow tip
  FIX: Paint.Join.MITER + strokeMiter = 10f. Use FILL not STROKE for filled arrows.

PITFALL 4: Double-headed arrows asymmetric
  FIX: For start arrow, use angle + PI (add 180°) to reverse direction.

PITFALL 5: Arrow too small / too large
  FIX: Use max(strokeWidth * multiplier, minimumDp). Never use fixed pixels.
```

### Zoom-Aware Rendering

- Arrow proportions use `strokeWidth` which is in image-space
- When rendering inside `canvas.concat(viewMatrix)`, the viewMatrix handles scaling
- Minimum sizes (e.g., `10dp`) should be converted to image-space: `10.dp / zoom`
- This ensures arrows don't become invisible at low zoom or enormous at high zoom

## RESOLVED CONFLICTS

No new conflicts. Arrowhead spec is entirely in FINAL-complete-implementation-spec.md §3, which is the single authority.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Arrowhead picker in properties sheet | `ArrowheadPickerGrid` exists but not wired to properties | S18 (Properties Sheet) |
| Arrow size slider | `arrowSizeMultiplier` field exists but no UI to change it | S18 (Properties Sheet) |
| Dimension arrows | `drawDimensionArrows()` exists but no dimension elements yet | S17 (Measurement Tools) |

## TEST CRITERIA

1. **All 20 styles render:** Create a test that renders each ArrowStyle at tip=(200,200), angle=0°. Verify all produce visible output on canvas.
2. **Angle correctness:** Render CLOSED_FILLED at 0°, 45°, 90°, 135°, 180°, 225°, 270°, 315°. All point in the correct direction.
3. **Inset point:** Draw a straight line with CLOSED_FILLED end arrow. The line must stop at the base of the triangle, not poke through.
4. **Double-headed:** GrainlineArrowElement renders arrows at both ends. Both arrows point outward along the line direction.
5. **Filled vs blank:** CLOSED_FILLED = solid fill. CLOSED_BLANK = outline only with white/transparent center.
6. **Open wings:** OPEN = two lines from tip, no closing base. OPEN_30 = narrower. OPEN_90 = wider.
7. **Dots:** DOT_FILLED = filled circle at endpoint. DOT_BLANK = outlined circle.
8. **Box/Diamond:** BOX_FILLED = filled square rotated with line angle. DIAMOND_FILLED = rotated 45° further.
9. **Line-based:** OBLIQUE = 45° slash. INTEGRAL = perpendicular line. CROSS = + mark.
10. **Special:** ORIGIN_INDICATOR = circle + radius line. DOUBLE_BARB = nested open wings. CONCAVE = scooped-base triangle.
11. **Scale with stroke:** Increase strokeWidth from 1dp to 10dp → arrow proportionally larger.
12. **arrowSizeMultiplier:** Set to 2.0 → arrow twice as large. Set to 0.5 → half size.
13. **Zoom behavior:** Zoom in 4× → arrow looks the same relative to the line (both scale together).
14. **Picker grid:** `ArrowheadPickerGrid` renders 20 + NONE cells. Tap selects. Selected has cyan ring.
15. **Replace placeholder:** Lines from S09 that used `drawPlaceholderArrow()` now use the real renderer with no visual regression.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `ArrowheadRenderer.kt` | Complete renderer object with all 20 styles |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `LineRenderUtils.kt` | `drawLineWithArrows()` + `drawDimensionArrows()` utility functions |
| `:core:ui` | `com.bcd.technotes.core.ui.components` | `ArrowheadPickerGrid.kt` | 5×4 composable grid picker |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:core:model` | `ArrowStyle.kt` | Replace stub enum with full 23-entry enum |
| `:core:drawing` | `TwoPointElement.kt` | Add `arrowSizeMultiplier: Float` abstract property (default 1.0f) |
| `:core:drawing` | `StraightLineElement.kt` | Replace `drawPlaceholderArrow()` with `ArrowheadRenderer.draw()`. Use `drawLineWithArrows()`. Add `arrowSizeMultiplier`. |
| `:core:drawing` | `GrainlineArrowElement.kt` | Replace placeholder arrows with `ArrowheadRenderer.draw()` at both endpoints. |
| `:core:drawing` | `ElementFactory.kt` | Pass arrow style defaults from `ToolDefaults` when creating elements |

### Unit Tests

| Module | Test File | What It Tests |
|--------|-----------|--------------|
| `:core:drawing` | `ArrowheadRendererTest.kt` | All 20 styles return valid inset points. Angles: 0°/45°/90°/180°/270°. NONE returns tip unchanged. Proportions scale with strokeWidth. |
| `:core:drawing` | `LineRenderUtilsTest.kt` | `drawLineWithArrows()` — inset points are correctly computed. Dimension flip triggers at threshold. |

---

*Session 10 Blueprint — v1.0*
