# Session 13 — Freehand Drawing + Smooth Curves

## GOAL

Implement the freehand curve drawing system: `FreehandCurveDrawer` (touch point collection + live preview), `CatmullRomSmoother` (centripetal Catmull-Rom spline → cubic Bezier Path with open and closed curve support and C1 continuity at the join), `SnapToCloseManager` (DRAWING → APPROACHING → SNAPPED states with visual feedback), and `reducePoints()` (Ramer-Douglas-Peucker point reduction). This session builds the reusable infrastructure that S14 (Hatching, Revision Cloud), S15 (Leader freehand path), and S29 (Decorated Path, Pattern Brush) all depend on. Also implements the standalone Freehand Curve tool accessible from the Shapes tray.

## DEPENDS ON

- **S07 (Tool Palette)** — `ToolPalette`, `ToolRegistry`, `ActiveTool.Draw(toolId)`, Shapes category tray
- **S08 (Snap Engine)** — `SnapEngine` for grid/endpoint snapping of start/end points, haptic feedback infrastructure
- **S03 (Drawing Surface)** — `EditableTouchImageView`, `DrawableElement` interface, `GestureRouter`, `screenToImage()`, rendering pipeline, `isDrawing` for chrome auto-hide
- **S09 (Lines + Selection)** — `SelectionHandler`, `CanvasViewModel` element CRUD, undo integration
- **S02 (Undo/Redo)** — `UndoManager` annotate stack

## SPEC REFERENCES

Read before coding:
- `FINAL-complete-implementation-spec.md` §11 (Smooth Curve Closure System — full algorithm, CatmullRom math, SnapToClose states, RDP reduction, visual feedback, complete Kotlin code)
- `FINAL-complete-implementation-spec.md` §1 (Global Architecture — Input Modes for finger vs stylus epsilon)
- `INTERACTION-SPEC.md` §8 (Gesture Routing — freehand draw gesture flow)
- `NEW-GRAPHIC-TOOLS-SPEC.md` §2.1 (Path Spine Types — freehand spine reuse for Decorated Path)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-09 (Snap Engine integration)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `GestureRouter.kt` | `:core:drawing` | Routes by mode+tool from S03 | Route freehand tool to `FreehandDrawHandler` |
| `SelectionHandler.kt` | `:core:drawing` | Universal select/move/delete from S09 | Reuse for selecting placed freehand curves |
| `CanvasViewModel.kt` | `:feature:canvas` | Element CRUD, isDrawing state | Add freehand element. isDrawing=true during draw. |
| `EditableTouchImageView.kt` | `:feature:canvas` | Touch handling + rendering | Route continuous touch events to `FreehandCurveDrawer`. Render live preview path. Render snap-to-close visual feedback. |
| `SnapEngine.kt` | `:core:drawing` | Snap detection from S08 | Snap start point on first tap. Snap end point if not closing. |
| `DrawableElement.kt` | `:core:drawing` | Interface from S03 | Implement for `FreehandCurveElement` |

## DELIVERABLES

### CatmullRomSmoother

1. **`CatmullRomSmoother` class** in `:core:drawing`:
   - Constructor params: `alpha: Float = 0.5f` (centripetal), `tension: Float = 0f`
   - `createPath(points: List<PointF>, closed: Boolean = false): Path`
   - Converts sampled touch points into a smooth Android `Path` using cubic Bezier segments
   - **Open curve:** For first/last segments that lack neighbors, use reflection: `P_mirror = 2*P_boundary - P_neighbor`
   - **Closed curve:**
     - Remove duplicate endpoint if last point ≈ first point (from snap)
     - Array wrapping: segment 0 uses `P[n-1]` as predecessor; final segment uses `P[0], P[1]` as successors
     - Result: perfect C1 tangent continuity at the join point. No special-case math — the wrap handles everything.
   - **catmullRomToBezier()** private method:
     - Takes 4 Catmull-Rom points → returns pair of cubic Bezier control points (cp1, cp2) for `Path.cubicTo()`
     - Uses centripetal parameterization: `d_ij = dist(P_i, P_j)^alpha`
     - Proven to never produce cusps or self-intersections (Yuksel et al., 2011)
   - Minimum: 2 points → straight line. 3+ points → smooth spline.

2. **Complete Kotlin implementation** (from FINAL-spec §11):
   ```kotlin
   class CatmullRomSmoother(
       private val alpha: Float = 0.5f,
       private val tension: Float = 0f
   ) {
       fun createPath(points: List<PointF>, closed: Boolean = false): Path
       private fun catmullRomToBezier(p0, p1, p2, p3): Pair<PointF, PointF>
       private fun wrapIndex(i: Int, n: Int, closed: Boolean): Int
   }
   ```

### SnapToCloseManager

3. **`SnapToCloseManager` class** in `:core:drawing`:
   ```
   STATES:
   DRAWING     — default, no proximity to start point
   APPROACHING — current point within previewRadius (30dp) of start
   SNAPPED     — current point within snapRadius (20dp) of start

   TRANSITIONS:
   DRAWING → APPROACHING:  enter preview zone, show blue pulsing ring
   APPROACHING → SNAPPED:  enter snap zone, show green glow + haptic CLOCK_TICK
   SNAPPED → APPROACHING:  moved back out of snap zone (still in preview)
   APPROACHING → DRAWING:  moved fully out of preview zone
   * → END:                ACTION_UP. If SNAPPED → closed=true. Else → closed=false.
   ```

4. **Visual feedback rendering** (called from `EditableTouchImageView`):
   - **APPROACHING:** Blue pulsing ring around start point
     - Ring: blue (#2196F3), 30% opacity, pulsing 1.0×–1.3× scale, 1s cycle
     - Center dot: blue, 3dp radius
   - **SNAPPED:** Green glow + solid ring
     - Glow: green (#4CAF50) with BlurMaskFilter, radius × 1.5
     - Ring: green, 2.5dp stroke, at snapRadius
     - Center dot: green, 3dp radius
     - Haptic: `CLOCK_TICK` on state transition to SNAPPED
   - **DRAWING:** No feedback

5. **Parameters:**
   - `snapRadiusDp: Float = 20f` — converted to image-space using current density
   - `previewRadiusDp: Float = 30f` — preview zone is larger than snap zone
   - Start point recorded on `onDrawStart()`

### Point Reduction (Ramer-Douglas-Peucker)

6. **`reducePoints()` function** in `:core:drawing`:
   - Recursive RDP algorithm
   - `epsilon` parameter: 2dp for finger input, 1dp for stylus (finer precision)
   - Input: raw touch points (hundreds per second)
   - Output: reduced point set preserving shape
   - Used before passing to CatmullRomSmoother

7. **Helper: `perpendicularDistance()`** — distance from point to line segment

### FreehandCurveDrawer

8. **`FreehandCurveDrawer` class** in `:core:drawing`:
   - Integrates: raw point collection → RDP reduction → CatmullRom smoothing → snap-to-close detection
   - API:
     ```kotlin
     fun onTouchDown(x: Float, y: Float)
     fun onTouchMove(x: Float, y: Float, density: Float): SnapToCloseManager.SnapState
     fun onTouchUp(): FreehandCurveResult
     fun getPreviewPath(): Path?
     ```
   - `onTouchMove()` returns snap state for visual feedback rendering
   - `getPreviewPath()` returns current reduced+smoothed path for live preview
   - `onTouchUp()` returns final result:
     ```kotlin
     data class FreehandCurveResult(
         val path: Path,
         val controlPoints: List<PointF>,
         val isClosed: Boolean
     )
     ```

### FreehandCurveElement

9. **`FreehandCurveElement` class** implementing `DrawableElement`:
   ```kotlin
   data class FreehandCurveData(
       val controlPoints: List<PointF>,  // reduced points (not raw)
       val isClosed: Boolean,
       val strokeWidth: Float,
       val color: Int,
       val dashType: DashType = DashType.SOLID,
       val layer: String,
       val opacity: Float = 1.0f,
       val isLocked: Boolean = false
   )
   ```
   - `draw()`: reconstruct `Path` from controlPoints via CatmullRomSmoother, then `canvas.drawPath()`
   - **Optimization:** Cache the generated `Path`. Only regenerate on data change (undo/edit).
   - `hitTest()`: use `Path` with `computeBounds()` for coarse check, then `PathMeasure` to walk the path and check minimum distance from tap point
   - `getEndpoints()`: first and last controlPoints (for snap targets)

### Freehand Draw Handler

10. **`FreehandDrawHandler` class** in `:core:drawing`:
    - Wraps `FreehandCurveDrawer` with the gesture state machine:
      ```
      IDLE → (ACTION_DOWN with freehand tool) → DRAWING
        Create FreehandCurveDrawer. Set isDrawing = true.
      DRAWING → (ACTION_MOVE) → DRAWING
        Feed point to drawer. Get preview path. Get snap state.
        Render preview + snap feedback on canvas.
      DRAWING → (ACTION_UP) → PLACED
        Get FreehandCurveResult.
        Create FreehandCurveElement from result.
        Push to undo stack. Set isDrawing = false.
      PLACED → IDLE
      ```

### Pressure Sensitivity (Stylus)

11. **Stylus pressure → variable stroke width:**
    - When `MotionEvent.getToolType() == TOOL_TYPE_STYLUS`:
      - Collect `pressure` value (0.0–1.0) alongside each point
      - Store as `List<Float>` parallel to controlPoints
      - During rendering: interpolate strokeWidth per segment based on pressure
      - Implementation: break path into segments, each drawn with different strokeWidth
    - When finger input: uniform strokeWidth (no pressure data)

### Live Preview Rendering

12. **During draw (in `EditableTouchImageView`):**
    ```
    RENDER ORDER (on top of existing annotations):
    1. Preview path: thin line (current strokeWidth), current color, 70% opacity
    2. Snap-to-close visual feedback (APPROACHING ring or SNAPPED glow)
    3. Start point indicator: small cyan dot (4dp) at first touch point
    ```

## DATA MODELS

```kotlin
// In :core:drawing — FreehandCurveResult.kt
data class FreehandCurveResult(
    val path: Path,
    val controlPoints: List<PointF>,
    val isClosed: Boolean
)

// In :core:drawing — SnapToCloseManager.kt
sealed class SnapState {
    object DRAWING : SnapState()
    data class APPROACHING(val distance: Float) : SnapState()
    object SNAPPED : SnapState()
}

// In :core:model — FreehandCurveData.kt
data class FreehandCurveData(
    val controlPoints: List<PointF>,
    val isClosed: Boolean,
    val strokeWidth: Float,
    val color: Int,
    val dashType: DashType = DashType.SOLID,
    val pressureValues: List<Float>? = null,  // parallel to controlPoints, stylus only
    val layer: String,
    val opacity: Float = 1.0f,
    val isLocked: Boolean = false
)
```

## KEY IMPLEMENTATION DETAILS

### Catmull-Rom to Bezier Conversion (Core Math)

The centripetal parameterization prevents cusps:
```
d01 = dist(P0, P1)^alpha   (alpha=0.5 for centripetal)
d12 = dist(P1, P2)^alpha
d23 = dist(P2, P3)^alpha

t1 = (1-tension) * d12 * ((P1-P0)/d01 - (P2-P0)/(d01+d12) + (P2-P1)/d12)
t2 = (1-tension) * d12 * ((P2-P1)/d12 - (P3-P1)/(d12+d23) + (P3-P2)/d23)

cp1 = P1 + t1/3
cp2 = P2 - t2/3

Path.cubicTo(cp1.x, cp1.y, cp2.x, cp2.y, P2.x, P2.y)
```

### Closed Curve Array Wrapping

For n control points forming a closed loop:
```
wrapIndex(i, n, closed=true) = ((i % n) + n) % n

Segment i uses: P[wrap(i-1)], P[wrap(i)], P[wrap(i+1)], P[wrap(i+2)]
Total segments = n (not n-1 as with open curves)

On closure: if last point ≈ first point (distance < 1px), drop the last point.
The CatmullRom wrap creates the smooth connection automatically.
```

### Performance: Live Preview

- `reducePoints()` + `CatmullRomSmoother.createPath()` is called on EVERY `ACTION_MOVE`
- Typically 60 calls/second during drawing
- RDP reduction keeps point count manageable (typically <50 control points for a curve)
- CatmullRom conversion is O(n) where n = reduced points
- Path creation is fast — this combination easily runs within 16ms frame budget
- For very long curves (>200 reduced points): skip every other frame for smoothing, but always update raw points

### Path Hit-Testing

Freehand curves don't have simple geometric hit-tests. Use `PathMeasure`:
```kotlin
fun hitTestPath(path: Path, point: PointF, hitRadius: Float): Boolean {
    val measure = PathMeasure(path, false)
    val pos = FloatArray(2)
    val step = hitRadius / 2f  // sample every half-hitRadius
    var distance = 0f
    while (distance <= measure.length) {
        measure.getPosTan(distance, pos, null)
        val dx = pos[0] - point.x
        val dy = pos[1] - point.y
        if (dx * dx + dy * dy <= hitRadius * hitRadius) return true
        distance += step
    }
    return false
}
```

### Integration Points for Future Sessions

The classes built here are reused by:
- **S14 (Drag-Area Shapes):** `FreehandCurveDrawer` for hatching boundary and revision cloud outline
- **S15 (Leader+Text):** Possible freehand leader path option
- **S29 (Advanced Tools):** `CatmullRomSmoother` for Decorated Path spine, Pattern Brush stamp path
- **S14 Revision Cloud:** Takes the closed freehand path and converts the outline to bumps (different rendering, same input pipeline)

Design the API so these consumers can reuse without modification:
- `FreehandCurveDrawer` is standalone — doesn't know about elements or undo
- `CatmullRomSmoother` is a pure function class — takes points, returns Path
- `SnapToCloseManager` is standalone — takes points, returns state

## RESOLVED CONFLICTS

No new conflicts. The freehand system spec is entirely in FINAL-complete-implementation-spec.md §11, which is the single authority. The `CatmullRomSmoother` and `SnapToCloseManager` are standalone utilities with no competing definitions.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| Variable-width stroke rendering (pressure) | Store pressure data per point. For now: render uniform strokeWidth even when pressure data exists. | Future polish (pressure rendering is enhancement) |
| Freehand curve editing (move control points) | Once placed, freehand curves can be moved/deleted but individual control points cannot be edited | S18 (Properties Sheet) could add point editing, or defer |
| Freehand as boundary input for Hatching/Cloud | `FreehandCurveDrawer` returns result. Consumers not yet built. | S14 (Drag-Area Shapes) |

## TEST CRITERIA

1. **Draw freehand curve:** Press down → drag finger across canvas → release. Smooth curve appears (not jagged polyline).
2. **Live preview:** During drag, see the smoothed curve preview updating in real-time.
3. **Open curve:** Draw a curve where endpoint is far from start → open curve placed.
4. **Snap-to-close feedback:** Draw a curve and bring endpoint near start:
   - Within 30dp: blue pulsing ring appears (APPROACHING)
   - Within 20dp: green glow + haptic (SNAPPED)
   - Release in SNAPPED state → closed curve
5. **Closed curve smoothness:** Close a curve → the join point should be smooth (no corner/kink visible). C1 continuity.
6. **Move away from snap:** Enter SNAPPED zone → drag away → feedback disappears, open curve if released.
7. **RDP reduction:** Draw a very detailed curve → reduced points should be << raw touch points. Visual shape preserved.
8. **Stylus vs finger:** Stylus uses epsilon=1dp (finer reduction). Finger uses epsilon=2dp (coarser).
9. **Select freehand curve:** With Select tool, tap on a placed curve → selected (context bar appears).
10. **Move curve:** Drag selected curve → moves. Undo → returns.
11. **Delete curve:** Select → swipe up or 🗑 → deleted. Undo → restored.
12. **Undo draw:** Draw curve → undo → curve removed. Redo → restored.
13. **Chrome auto-hide:** During freehand draw, toolbar and top bar auto-hide. On release, they return.
14. **Zoom/pan still works:** Two-finger gestures still zoom/pan even during freehand mode (second finger cancels drawing).
15. **Performance:** Drawing at 60fps feels smooth — no visible lag between finger and preview path.
16. **Multiple curves:** Draw 5 freehand curves, some open, some closed. All render correctly. Can select any.
17. **Long curve:** Draw a very long curve (500+ raw touch points) → still performs well.
18. **CatmullRomSmoother standalone test:** Pass in known control points → verify output Path is smooth. Open and closed variants.
19. **SnapToCloseManager standalone test:** Simulate move events → verify state transitions at correct distances.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:drawing` | `com.bcd.technotes.core.drawing.curves` | `CatmullRomSmoother.kt` | Centripetal spline → Path converter with closed-loop support |
| `:core:drawing` | `com.bcd.technotes.core.drawing.curves` | `SnapToCloseManager.kt` | Snap detection state machine + visual feedback data |
| `:core:drawing` | `com.bcd.technotes.core.drawing.curves` | `PointReduction.kt` | `reducePoints()` RDP algorithm + `perpendicularDistance()` |
| `:core:drawing` | `com.bcd.technotes.core.drawing.curves` | `FreehandCurveDrawer.kt` | Integration class: raw points → reduced → smoothed → snap check |
| `:core:drawing` | `com.bcd.technotes.core.drawing.curves` | `FreehandCurveResult.kt` | Result data class |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `FreehandCurveElement.kt` | DrawableElement implementation for placed freehand curves |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `FreehandDrawHandler.kt` | Gesture handler wrapping FreehandCurveDrawer with state machine |
| `:core:model` | `com.bcd.technotes.core.model` | `FreehandCurveData.kt` | Serializable data class for persistence |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:core:drawing` | `GestureRouter.kt` | Route Freehand tool (from Shapes tray) to `FreehandDrawHandler` |
| `:core:drawing` | `ElementFactory.kt` | Add freehand tool ID → `FreehandCurveElement` creation |
| `:feature:canvas` | `EditableTouchImageView.kt` | Render live preview path during draw. Render snap-to-close feedback (rings/glow). |
| `:feature:canvas` | `CanvasViewModel.kt` | Wire freehand draw completion → `addElement()` + undo |
| `:core:drawing` | `DrawableElement.kt` | `FreehandCurveElement` implements all interface methods |

### Unit Tests

| Module | Test File | What It Tests |
|--------|-----------|--------------|
| `:core:drawing` | `CatmullRomSmootherTest.kt` | Open path with 3/5/10 points → valid Path. Closed path → join smooth (tangent test). 2 points → straight line. Array wrap indices correct. |
| `:core:drawing` | `SnapToCloseManagerTest.kt` | State transitions: DRAWING→APPROACHING→SNAPPED→back. Distance thresholds. SNAPPED on UP → closed=true. |
| `:core:drawing` | `PointReductionTest.kt` | Straight line → 2 points. Zigzag → preserves peaks. Circle → ~12-16 points. Epsilon affects reduction aggressiveness. |
| `:core:drawing` | `FreehandCurveDrawerTest.kt` | Full pipeline: down→move×N→up. Closed vs open result. Preview path non-null during draw. |

---

*Session 13 Blueprint — v1.0*
