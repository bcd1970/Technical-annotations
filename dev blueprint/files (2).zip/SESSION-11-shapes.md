# Session 11 — Tap-to-Place Shapes

## GOAL

Implement the shape primitives from Groups B and D: tap-to-place shapes (#13–#17 Circle variants, #20 Triangle, #21 Rectangle, #22 Rect+Pattern, #23 Labeled Rect, #24 Diamond), the `TapToPlaceDrawHandler` gesture state machine, and resize handles (8-point for rectangles, 4-cardinal for circles). Text entry for labeled shapes (#14, #15, #23) opens keyboard after placement. Drag-area shapes (#36 Hatching Fill, #39 Revision Cloud) are deferred to S14 which depends on the freehand system from S13.

## DEPENDS ON

- **S07 (Tool Palette)** — `ToolPalette`, `ToolRegistry`, `ActiveTool.Draw(toolId)`, Shapes category tray with tool activation
- **S03 (Drawing Surface)** — `EditableTouchImageView`, `DrawableElement` interface, `GestureRouter`, `screenToImage()`, annotations list, rendering pipeline
- **S09 (Lines + Selection)** — `SelectionHandler` (tap-to-select, move, delete, context bar wiring), `ElementFactory` pattern, `CanvasViewModel` element CRUD
- **S02 (Undo/Redo)** — `UndoManager` annotate stack

## SPEC REFERENCES

Read before coding:
- `FINAL-complete-implementation-spec.md` §5 (Group B: Tap-to-Place — data classes for #12–#30)
- `GRAPHIC-ELEMENT-EDITING-SPEC.md` §6 (Shapes — fill mode, radius, corner radius, concentric ratio, crosshair extension, rectangle aspect lock, pattern types, triangle orientation/variant, diamond aspect)
- `INTERACTION-SPEC.md` §8 (Gesture Routing — tap-to-place gesture flow)
- `IMPLEMENTATION-BLUEPRINT.md` Part 2: P-05 (Progressive Disclosure)

## EXISTING CODE TO INTEGRATE WITH

| File | Module | What It Does | Integration Notes |
|------|--------|-------------|-------------------|
| `GestureRouter.kt` | `:core:drawing` | Routes by mode+tool | Add route for Shapes-category tools → `TapToPlaceDrawHandler` |
| `SelectionHandler.kt` | `:core:drawing` | Universal select/move/delete from S09 | Reuse for shape selection. Add resize handle hit-testing. |
| `CanvasViewModel.kt` | `:feature:canvas` | Element CRUD from S09 | Reuse `addElement()`, `deleteElement()`, etc. |
| `ElementFactory.kt` | `:core:drawing` | Creates elements by toolId | Add shape tool IDs (13–17, 20–24) |
| `DrawableElement.kt` | `:core:drawing` | Interface from S03 | Implement for each shape type |
| `EditableTouchImageView.kt` | `:feature:canvas` | Touch handling + rendering | Add resize handle rendering + drag logic |
| `ToolRegistry.kt` | `:core:model` | Tool definitions from S07 | Shapes category already has entries |

## DELIVERABLES

### Tap-to-Place Gesture Handler

1. **`TapToPlaceDrawHandler` class** in `:core:drawing`:
   ```
   STATE MACHINE:
   IDLE → (tap on canvas with shape tool) → PLACED
     Element appears at tap point with default size.
     Resize handles appear immediately.
     For labeled shapes: keyboard opens after 200ms delay.
   PLACED → (drag handle) → RESIZING
     Live resize preview. Aspect ratio constraint depending on shape.
   RESIZING → (release handle) → PLACED
     Push resize to undo stack.
   PLACED → (tap elsewhere on canvas) → NEW_PLACEMENT
     Previous shape deselects. New shape placed at new tap point.
   PLACED → (tap different tool or done) → IDLE
     Shape finalized.
   ```

2. **Default sizes on placement:**
   - Circles: radius = 30dp (image-space, adjusted by zoom)
   - Rectangles: 60dp × 40dp
   - Triangle: bounding circle radius = 30dp
   - Diamond: bounding square side = 40dp

### Shape Elements (10 types)

Each shape gets a concrete `DrawableElement` implementation in `:core:drawing`:

3. **#13 — `CircleElement`:**
   - `center: PointF`, `radius: Float`
   - Renders: `canvas.drawCircle(center.x, center.y, radius, paint)`
   - Fill mode support: STROKE_ONLY (default), FILLED, FILL_AND_STROKE
   - Hit-test: distance from center ≤ radius + hitRadius for interior, or |distance - radius| ≤ hitRadius for stroke-only
   - Resize handles: 4 cardinal points (N, E, S, W) on the circle edge. Drag handle → change radius (maintain center).

4. **#14 — `CircleTextElement`:**
   - Extends `CircleElement` with `text: String`, `text2: String?`
   - Upper text = function code (M, A, TT, SD...), lower text = tag number
   - Auto-grow: if text wider than (diameter - 8dp padding), radius expands to fit
   - Font scaling: max 14sp, min 7sp — scale down if text too wide even after grow
   - After placement: keyboard opens IMMEDIATELY for text input
   - First Enter or tab → focus moves to text2 field
   - Tap ✓ → finalize text

5. **#15 — `CircleDividerElement`:**
   - Extends `CircleElement` with `upperText: String`, `lowerText: String`
   - Horizontal divider line at vertical center of circle
   - Two text zones: upper half, lower half
   - After placement: keyboard opens for upperText, tab moves to lowerText

6. **#16 — `CircleCrossElement`:**
   - Extends `CircleElement` with optional `labelBelow: String?`
   - Crosshair lines extending to circle boundary (default TO_EDGE)
   - `crosshairExtension: CrosshairExtension` enum: TO_EDGE, OVERSHOOT, THROUGH
   - `overshootAmount: Float = 5f` (when OVERSHOOT selected)

7. **#17 — `ConcentricCirclesElement`:**
   - `center: PointF`, `outerR: Float`, `innerR: Float`
   - Inner/outer ratio default: 60% (innerR = outerR * 0.6)
   - Two concentric circles, same center
   - Resize handles: 4 on outer circle + 4 on inner circle (8 total)

8. **#20 — `TriangleElement`:**
   - `center: PointF`, `radius: Float` (bounding circle radius)
   - `orientation: TriangleOrientation` — UP, DOWN, LEFT, RIGHT (default UP)
   - `variant: TriangleVariant` — FLAG, DATUM, BENCHMARK, LEVEL, REVISION_DELTA
   - Datum variant: optional attached rectangle below
   - Rendered as equilateral triangle inscribed in bounding circle

9. **#21 — `RectangleElement`:**
   - `center: PointF`, `width: Float`, `height: Float`
   - `cornerRadius: Float = 0f` (0 = sharp corners, up to 50% of shorter side)
   - 8 resize handles: 4 corners + 4 midpoints
   - Corner drag: free resize. Midpoint drag: resize along one axis.
   - Aspect lock toggle (stored as `aspectLocked: Boolean`)

10. **#22 — `RectPatternElement`:**
    - Extends `RectangleElement` with `internalPattern: InternalPattern`
    - Patterns: X_CROSS, SINGLE_DIAGONAL, PARALLEL, GRID
    - Pattern rendered inside rectangle bounds with clipping

11. **#23 — `LabeledRectElement`:**
    - Extends `RectangleElement` with `label: String`
    - `autoSize: Boolean = true`: when true, rect grows with text + 8dp padding; when false, text scales to fit
    - After placement: keyboard opens for label text
    - Text centered within rectangle

12. **#24 — `DiamondElement`:**
    - `center: PointF`, `width: Float`, `height: Float`
    - Rendered as rectangle rotated 45° (or explicit diamond path)
    - Default: square diamond (width == height). Aspect ratio adjustable: width/height 0.5–2.0

### Resize Handle System

13. **`ResizeHandleManager` class** in `:core:drawing`:
    - Generates handle positions for each shape type
    - Hit-tests handle taps (16dp touch target around each 8dp handle)
    - Computes new shape dimensions from handle drag delta
    - Handles are drawn in screen-space (fixed 8dp circles regardless of zoom)
    - Handle colors: neutral gray (#888888) fill, white border, selected handle = cyan

14. **Handle types per shape:**
    - Rectangles: 8 handles (4 corners: free resize, 4 midpoints: axis-constrained)
    - Circles: 4 cardinal handles (N, E, S, W — all change radius equally)
    - Concentric: 8 handles (4 outer + 4 inner, drag inner only changes inner radius)
    - Diamond/Triangle: 4 handles on bounding box corners
    - All: drag center of shape → move (handled by existing `SelectionHandler`)

### Fill Mode System

15. **`ShapeFillMode` enum and `ShapeFillConfig` data class:**
    ```kotlin
    enum class ShapeFillMode {
        STROKE_ONLY,    // outline only (default)
        FILLED,         // solid fill, no stroke
        FILL_AND_STROKE // both fill and outline
    }

    data class ShapeFillConfig(
        val mode: ShapeFillMode = ShapeFillMode.STROKE_ONLY,
        val fillColor: Int = Color.WHITE,
        val fillOpacity: Float = 1.0f
    )
    ```
    - All shape elements include `fillConfig: ShapeFillConfig`
    - Rendering: when FILLED or FILL_AND_STROKE, draw fill first, then stroke on top

### Text Entry for Labeled Shapes

16. **Text entry flow:**
    - After shape placement (#14, #15, #23): 200ms delay → system keyboard opens
    - `TextEntryOverlay` composable positioned at shape center
    - TextField with transparent background, text renders live on canvas
    - Tap ✓ (keyboard Done) → text committed, keyboard dismisses
    - If user taps canvas elsewhere before committing → text saved as-is (even empty)
    - Double-tap a labeled shape later → keyboard reopens for editing

## DATA MODELS

```kotlin
// In :core:model — ShapeModels.kt

enum class ShapeFillMode { STROKE_ONLY, FILLED, FILL_AND_STROKE }

data class ShapeFillConfig(
    val mode: ShapeFillMode = ShapeFillMode.STROKE_ONLY,
    val fillColor: Int = Color.WHITE,
    val fillOpacity: Float = 1.0f
)

enum class InternalPattern { X_CROSS, SINGLE_DIAGONAL, PARALLEL, GRID }

enum class TriangleOrientation { UP, DOWN, LEFT, RIGHT }
enum class TriangleVariant { FLAG, DATUM, BENCHMARK, LEVEL, REVISION_DELTA }

enum class CrosshairExtension { TO_EDGE, OVERSHOOT, THROUGH }
```

```kotlin
// Each concrete element data class includes at minimum:
// - id: String (UUID)
// - center: PointF (image-space)
// - size parameters (radius, width/height, etc.)
// - strokeWidth: Float
// - color: Int
// - fillConfig: ShapeFillConfig
// - layer: String
// - opacity: Float = 1.0f
// - rotation: Float = 0f
// - isLocked: Boolean = false
```

## KEY IMPLEMENTATION DETAILS

### Rendering Order

Within each shape's `draw()` function:
1. Apply rotation if non-zero: `canvas.save()` → `canvas.rotate(rotation, center.x, center.y)`
2. Draw fill (if FILLED or FILL_AND_STROKE)
3. Draw stroke (if STROKE_ONLY or FILL_AND_STROKE)
4. Draw internal features (crosshairs, divider line, pattern, text)
5. Restore canvas

### Rectangle Internal Patterns (#22)

```kotlin
fun drawInternalPattern(canvas: Canvas, rect: RectF, pattern: InternalPattern, paint: Paint) {
    canvas.save()
    canvas.clipRect(rect)
    when (pattern) {
        X_CROSS -> {
            canvas.drawLine(rect.left, rect.top, rect.right, rect.bottom, paint)
            canvas.drawLine(rect.left, rect.bottom, rect.right, rect.top, paint)
        }
        SINGLE_DIAGONAL -> {
            canvas.drawLine(rect.left, rect.top, rect.right, rect.bottom, paint)
        }
        PARALLEL -> {
            // Horizontal lines at 25%, 50%, 75% height
            for (i in 1..3) {
                val y = rect.top + rect.height() * i / 4f
                canvas.drawLine(rect.left, y, rect.right, y, paint)
            }
        }
        GRID -> {
            // Horizontal + vertical at 33%, 66%
            for (i in 1..2) {
                val y = rect.top + rect.height() * i / 3f
                val x = rect.left + rect.width() * i / 3f
                canvas.drawLine(rect.left, y, rect.right, y, paint)
                canvas.drawLine(x, rect.top, x, rect.bottom, paint)
            }
        }
    }
    canvas.restore()
}
```

### Hit-Testing Shapes

- **Circle:** Two modes:
  - STROKE_ONLY: `|distance(tap, center) - radius| ≤ hitRadius`
  - FILLED/FILL_AND_STROKE: `distance(tap, center) ≤ radius + hitRadius`
- **Rectangle:** Point-in-rect with `hitRadius` expansion on all sides. Account for `cornerRadius`.
- **Diamond:** Transform tap point by inverse rotation, then point-in-rect.
- **Triangle:** Point-in-triangle test using barycentric coordinates.

### Scale-Aware Rendering

- All shape dimensions are in image-space (stored in image coordinates)
- Rendering happens inside `canvas.concat(viewMatrix)` — zoom handled automatically
- Resize handles are drawn OUTSIDE the viewMatrix (screen-space, fixed pixel size)
- Hit-test for handles uses screen-space coordinates with 16dp touch targets

## RESOLVED CONFLICTS

No new conflicts. Shape specs come from FINAL-complete-implementation-spec.md §5 (data classes) and GRAPHIC-ELEMENT-EDITING-SPEC.md §6 (editing properties). The master plan session S11 removes Hatching Fill and Revision Cloud to S14, which is the correct ordering since those depend on freehand drawing from S13.

## STUB REQUIREMENTS

| Feature | What to stub | Session that implements |
|---------|-------------|----------------------|
| #36 Hatching Fill | Listed in Shapes tray, shows toast "Coming Soon" | S14 (Drag-Area Shapes) |
| #39 Revision Cloud | Listed in Shapes tray, shows toast "Coming Soon" | S14 (Drag-Area Shapes) |
| #46 Decorated Path | Listed in Shapes tray, shows toast "Coming Soon" | S29 (Advanced Tools) |
| Fill mode picker UI | `ShapeFillConfig` data exists, rendering works, but no picker UI yet | S18 (Properties Sheet) |
| Corner radius slider | `cornerRadius` field exists, rendering works, but no slider UI | S18 (Properties Sheet) |
| Crosshair extension picker | `CrosshairExtension` enum exists, rendering defaults to TO_EDGE | S18 (Properties Sheet) |
| Triangle variant picker | `TriangleVariant` enum exists, defaults to FLAG | S18 (Properties Sheet) |
| Concentric ratio slider | Ratio adjustable via inner circle handles only. No slider. | S18 (Properties Sheet) |

## TEST CRITERIA

1. **Place circle:** Select Circle tool → tap canvas → circle appears at tap point with default radius.
2. **Resize circle:** Drag cardinal handle outward → radius increases. Drag inward → radius decreases. Circle stays centered.
3. **Place Circle+Text (#14):** Tap canvas → circle appears → keyboard opens → type "M-101" → ✓ → text visible inside circle.
4. **Circle auto-grow:** Type very long text in #14 → circle radius expands to fit.
5. **Place Circle+Divider (#15):** Tap → circle + horizontal line → keyboard for upper text → tab → lower text → ✓.
6. **Circle+Crosshairs (#16):** Tap → circle with crosshairs extending to edge.
7. **Concentric (#17):** Tap → two concentric circles. Drag outer handle → outer grows. Drag inner handle → inner changes independently.
8. **Place rectangle:** Select Rectangle → tap → rectangle with default size. 8 handles visible.
9. **Resize rectangle (corner):** Drag corner handle → free resize.
10. **Resize rectangle (midpoint):** Drag midpoint → constrained to one axis.
11. **Rect+Pattern (#22):** Tap → rectangle with X_CROSS pattern inside.
12. **Labeled Rect (#23):** Tap → rectangle → keyboard → type label → visible inside.
13. **Triangle (#20):** Tap → equilateral triangle, default UP orientation.
14. **Diamond (#24):** Tap → diamond shape (square rotated 45°).
15. **Fill mode:** Create circle with STROKE_ONLY → outline. Change to FILLED → solid fill. Change to FILL_AND_STROKE → both.
16. **Selection:** Tap on placed shape → selected (cyan handles, context bar).
17. **Move:** Drag inside selected shape → moves.
18. **Delete:** Select shape → swipe up or 🗑 → deleted. Undo → restored.
19. **Multiple shapes:** Place 5 different shapes. All render correctly. Can select any.
20. **Double-tap labeled shape:** Double-tap Circle+Text → keyboard reopens for text editing.
21. **Undo add:** Place shape → undo → removed. Redo → restored.
22. **Undo resize:** Resize → undo → original size restored.
23. **Rotation survival:** Rotate device → all shapes at correct positions and sizes.

## FILES TO CREATE / MODIFY

### Create

| Module | Package | File | Purpose |
|--------|---------|------|---------|
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `CircleElement.kt` | #13 base circle renderer |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `CircleTextElement.kt` | #14 circle + text |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `CircleDividerElement.kt` | #15 circle + divider |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `CircleCrossElement.kt` | #16 circle + crosshairs |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `ConcentricCirclesElement.kt` | #17 concentric |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `TriangleElement.kt` | #20 triangle with variants |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `RectangleElement.kt` | #21 base rectangle |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `RectPatternElement.kt` | #22 rect + pattern |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `LabeledRectElement.kt` | #23 labeled rect |
| `:core:drawing` | `com.bcd.technotes.core.drawing.elements` | `DiamondElement.kt` | #24 diamond |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `TapToPlaceDrawHandler.kt` | Gesture state machine for tap-to-place |
| `:core:drawing` | `com.bcd.technotes.core.drawing` | `ResizeHandleManager.kt` | Handle generation, hit-test, drag computation |
| `:core:model` | `com.bcd.technotes.core.model` | `ShapeModels.kt` | ShapeFillMode, InternalPattern, TriangleOrientation, etc. |

### Modify

| Module | File | Changes |
|--------|------|---------|
| `:core:drawing` | `GestureRouter.kt` | Route Shapes-category tools to `TapToPlaceDrawHandler` |
| `:core:drawing` | `ElementFactory.kt` | Add toolIds 13–17, 20–24 → shape element creation |
| `:core:drawing` | `SelectionHandler.kt` | Add resize handle hit-testing: if tap is on a handle, enter RESIZING mode instead of MOVE |
| `:feature:canvas` | `EditableTouchImageView.kt` | Render resize handles for selected shapes (in screen-space). Route handle drags to `ResizeHandleManager`. |
| `:feature:canvas` | `CanvasViewModel.kt` | Add `resizeElement()` with undo. Add text entry state management for labeled shapes. |
| `:core:drawing` | `DrawableElement.kt` | Add optional `getResizeHandles(viewMatrix): List<HandleInfo>` to interface |

### Unit Tests

| Module | Test File | What It Tests |
|--------|-----------|--------------|
| `:core:drawing` | `CircleElementTest.kt` | `hitTest()` stroke-only vs filled, `getResizeHandles()` positions, resize by handle drag |
| `:core:drawing` | `RectangleElementTest.kt` | Corner vs midpoint resize, aspect lock, corner radius rendering |
| `:core:drawing` | `TapToPlaceDrawHandlerTest.kt` | State machine: IDLE→PLACED→RESIZING→PLACED. Default sizes correct. |
| `:core:drawing` | `ResizeHandleManagerTest.kt` | Handle positions for each shape type. Hit-test accuracy. Drag delta computation. |

---

*Session 11 Blueprint — v1.0*
